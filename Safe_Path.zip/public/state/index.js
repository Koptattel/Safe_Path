﻿export function createAppState() {
  return {
    analysisTimer: null,

    appMode: "idle",

    cameraReady: false,
    detectorReady: false,

    cameraQualityTimer: null,
    cameraQualityStatus: "unknown",
    lastCameraQualityWarningAt: 0,

    lastHintText: "",
    lastHintLevel: "safe",
    lastSpokenAt: 0,

    lastDetectionsCount: 0,
    lastMainObstacle: null
  };
}
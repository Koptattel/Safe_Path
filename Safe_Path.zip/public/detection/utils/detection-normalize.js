﻿const FORWARD_ZONE_LEFT =
  0.20;

const FORWARD_ZONE_RIGHT =
  0.80;

const MIN_SCORE =
  0.25;

const STAIRS_MIN_SCORE =
  0.55;

const MIN_BOX_AREA_RATIO =
  0.002;

const LOW_PRIORITY_LABELS =
  new Set([
    "chair",
    "couch",
    "bed",
    "dining table",
    "bench",
    "potted plant",
    "suitcase",
    "backpack",
    "handbag",
    "bottle",
    "cup",
    "book",
    "laptop",
    "cell phone",
    "floor",
    "ceiling"
  ]);

const LABEL_ALIASES = {
  sofa:
    "couch",

  doorway:
    "door",

  "large-obstacle":
    "obstacle",

  "floor-obstacle":
    "obstacle"
};

function normalizeLabel(
  label
) {
  const value =
    String(label || "")
      .trim()
      .toLowerCase();

  return (
    LABEL_ALIASES[value] ||
    value ||
    "unknown"
  );
}

function getBoxCenterX(
  box
) {
  return (
    Number(box?.x || 0) +
    Number(box?.width || 0) /
      2
  );
}

function getBoxBottomY(
  box
) {
  return (
    Number(box?.y || 0) +
    Number(box?.height || 0)
  );
}

function getBoxArea(
  box
) {
  return (
    Math.max(
      0,
      Number(box?.width || 0)
    ) *
    Math.max(
      0,
      Number(box?.height || 0)
    )
  );
}

function getAreaRatio(
  box,
  frameWidth,
  frameHeight
) {
  return (
    getBoxArea(box) /
    Math.max(
      1,
      frameWidth * frameHeight
    )
  );
}

function isInForwardZone(
  box,
  frameWidth
) {
  const centerX =
    getBoxCenterX(box);

  return (
    centerX >=
      frameWidth *
        FORWARD_ZONE_LEFT &&
    centerX <=
      frameWidth *
        FORWARD_ZONE_RIGHT
  );
}

function getPriority(
  label
) {
  if (
    label === "stairs"
  ) {
    return 100;
  }

  if (
    label === "door" ||
    label === "door-closed" ||
    label === "door-half-open" ||
    label === "door-open"
  ) {
    return 95;
  }

  if (
    label === "person"
  ) {
    return 90;
  }

  if (
    label === "obstacle"
  ) {
    return 85;
  }

  if (
    label === "wall"
  ) {
    return 80;
  }

  if (
    LOW_PRIORITY_LABELS.has(label)
  ) {
    return 10;
  }

  return 0;
}

function getThreshold(
  label
) {
  return label === "stairs"
    ? STAIRS_MIN_SCORE
    : MIN_SCORE;
}

function isRelevantLabel(
  label
) {
  return [
    "person",
    "stairs",
    "door",
    "door-closed",
    "door-half-open",
    "door-open",
    "obstacle",
    "wall",
    "chair",
    "dining table",
    "couch",
    "bed",
    "bench",
    "potted plant",
    "suitcase",
    "backpack",
    "handbag",
    "bottle",
    "cup",
    "book",
    "laptop",
    "cell phone"
  ].includes(label);
}

function normalizeBox(
  box
) {
  return {
    x:
      Number(box?.x || 0),

    y:
      Number(box?.y || 0),

    width:
      Math.max(
        0,
        Number(box?.width || 0)
      ),

    height:
      Math.max(
        0,
        Number(box?.height || 0)
      )
  };
}

export function normalizeDetections(
  rawDetections = [],
  frameWidth = 640,
  frameHeight = 480
) {
  if (
    !Array.isArray(rawDetections)
  ) {
    return [];
  }

  return rawDetections
    .map((item) => {
      const rawLabel =
        String(
          item?.rawLabel ||
          item?.label ||
          "unknown"
        )
          .trim()
          .toLowerCase();

      const label =
        normalizeLabel(
          item?.label ||
          rawLabel
        );

      const score =
        Math.max(
          0,
          Math.min(
            1,
            Number(item?.score || 0)
          )
        );

      const box =
        normalizeBox(
          item?.box
        );

      const areaRatio =
        getAreaRatio(
          box,
          frameWidth,
          frameHeight
        );

      return {
        ...item,

        rawLabel,

        label,

        score,

        box,

        areaRatio,

        centerX:
          getBoxCenterX(box),

        bottomY:
          getBoxBottomY(box),

        inForwardZone:
          isInForwardZone(
            box,
            frameWidth
          ),

        priority:
          getPriority(label),

        lowPriority:
          LOW_PRIORITY_LABELS.has(
            label
          )
      };
    })
    .filter(
      (item) =>
        isRelevantLabel(
          item.label
        )
    )
    .filter(
      (item) =>
        item.score >=
        getThreshold(item.label)
    )
    .filter(
      (item) =>
        item.areaRatio >=
          MIN_BOX_AREA_RATIO ||
        item.label === "person" ||
        item.label === "stairs"
    );
}

export function pickMainObstacle(
  detections = []
) {
  if (
    !Array.isArray(detections) ||
    detections.length === 0
  ) {
    return null;
  }

  return [...detections].sort(
    (a, b) => {
      if (
        a.inForwardZone !==
        b.inForwardZone
      ) {
        return (
          Number(b.inForwardZone) -
          Number(a.inForwardZone)
        );
      }

      if (
        a.priority !==
        b.priority
      ) {
        return (
          b.priority -
          a.priority
        );
      }

      if (
        a.bottomY !==
        b.bottomY
      ) {
        return (
          b.bottomY -
          a.bottomY
        );
      }

      if (
        a.areaRatio !==
        b.areaRatio
      ) {
        return (
          b.areaRatio -
          a.areaRatio
        );
      }

      return b.score - a.score;
    }
  )[0];
}
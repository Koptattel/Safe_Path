﻿const FORWARD_ZONE_LEFT = 0.28;
const FORWARD_ZONE_RIGHT = 0.72;

const MIN_SCORE = 0.25;
const STAIRS_MIN_SCORE = 0.60;

const MIN_BOX_AREA_RATIO = 0.008;

const LOW_PRIORITY_LABELS = new Set([
  "chair",
  "couch",
  "bed",
  "dining table",
  "bench",
  "potted plant",
  "suitcase",
  "backpack",
  "handbag"
]);

function normalizeLabel(label) {
  const value =
    String(label || "")
      .trim()
      .toLowerCase();

  if (
    value === "door-closed" ||
    value === "door-half-open" ||
    value === "door-open"
  ) {
    return "door";
  }

  if (value === "sofa") {
    return "couch";
  }

  if (
    value === "large-obstacle" ||
    value === "floor-obstacle"
  ) {
    return "obstacle";
  }

  if (value === "doorway") {
    return "door";
  }

  return value || "unknown";
}

function getBoxCenterX(box) {
  return box.x + box.width / 2;
}

function getBoxBottomY(box) {
  return box.y + box.height;
}

function getBoxArea(box) {
  return Math.max(
    0,
    box.width
  ) * Math.max(
    0,
    box.height
  );
}

function getAreaRatio(
  box,
  frameWidth,
  frameHeight
) {
  const frameArea =
    Math.max(
      1,
      frameWidth * frameHeight
    );

  return getBoxArea(box) /
    frameArea;
}

function isInForwardZone(
  box,
  frameWidth
) {
  const centerX =
    getBoxCenterX(box);

  return (
    centerX >=
      frameWidth *
        FORWARD_ZONE_LEFT &&
    centerX <=
      frameWidth *
        FORWARD_ZONE_RIGHT
  );
}

function getPriority(label) {
  if (label === "stairs") {
    return 100;
  }

  if (label === "person") {
    return 90;
  }

  if (label === "obstacle") {
    return 80;
  }

  if (label === "door") {
    return 60;
  }

  if (label === "wall") {
    return 20;
  }

  if (
    LOW_PRIORITY_LABELS.has(label)
  ) {
    return 5;
  }

  return 0;
}

function getScoreThreshold(label) {
  return label === "stairs"
    ? STAIRS_MIN_SCORE
    : MIN_SCORE;
}

function isRelevantLabel(label) {
  return [
    "door",
    "stairs",
    "person",
    "obstacle",
    "wall",
    "chair",
    "couch",
    "bed",
    "dining table",
    "bench",
    "potted plant",
    "suitcase",
    "backpack",
    "handbag"
  ].includes(label);
}

export function normalizeDetections(
  rawDetections = [],
  frameWidth = 640,
  frameHeight = 640
) {
  if (
    !Array.isArray(rawDetections)
  ) {
    return [];
  }

  return rawDetections
    .map((item) => {
      const rawLabel =
        String(
          item.label || "unknown"
        )
          .trim()
          .toLowerCase();

      const label =
        normalizeLabel(
          rawLabel
        );

      const score =
        Number(item.score || 0);

      const box =
        item.box || {
          x: 0,
          y: 0,
          width: 0,
          height: 0
        };

      const areaRatio =
        getAreaRatio(
          box,
          frameWidth,
          frameHeight
        );

      return {
        ...item,
        rawLabel,
        label,
        score,
        box,
        areaRatio,
        centerX:
          getBoxCenterX(box),
        bottomY:
          getBoxBottomY(box),
        inForwardZone:
          isInForwardZone(
            box,
            frameWidth
          ),
        priority:
          getPriority(label),
        lowPriority:
          LOW_PRIORITY_LABELS.has(
            label
          )
      };
    })
    .filter(
      (item) =>
        isRelevantLabel(
          item.label
        )
    )
    .filter(
      (item) =>
        item.score >=
        getScoreThreshold(
          item.label
        )
    )
    .filter(
      (item) =>
        item.areaRatio >=
          MIN_BOX_AREA_RATIO ||
        item.label === "person" ||
        item.label === "stairs"
    );
}

export function pickMainObstacle(
  detections = []
) {
  if (
    !Array.isArray(detections) ||
    detections.length === 0
  ) {
    return null;
  }

  return [...detections].sort(
    (a, b) => {
      if (
        a.inForwardZone !==
        b.inForwardZone
      ) {
        return Number(
          b.inForwardZone
        ) - Number(
          a.inForwardZone
        );
      }

      if (
        a.priority !==
        b.priority
      ) {
        return b.priority -
          a.priority;
      }

      if (
        a.bottomY !==
        b.bottomY
      ) {
        return b.bottomY -
          a.bottomY;
      }

      if (
        a.areaRatio !==
        b.areaRatio
      ) {
        return b.areaRatio -
          a.areaRatio;
      }

      return b.score - a.score;
    }
  )[0];
}

function getDoorText(item) {
  if (
    item.rawLabel ===
    "door-closed"
  ) {
    return "???????? ????? ???????.";
  }

  if (
    item.rawLabel ===
    "door-half-open"
  ) {
    return "???????????? ????? ???????.";
  }

  if (
    item.rawLabel ===
    "door-open"
  ) {
    return "???????? ????? ???????.";
  }

  return "????? ???????.";
}

function getHintText(item) {
  if (item.label === "stairs") {
    return "???????? ???????.";
  }

  if (item.label === "door") {
    return getDoorText(item);
  }

  if (item.label === "person") {
    return "??????? ???????.";
  }

  if (item.label === "obstacle") {
    return "??????????? ???????.";
  }

  if (item.lowPriority) {
    return `?????? ???????: ${item.label}.`;
  }

  if (item.label === "wall") {
    return "??????? ???????.";
  }

  return "?????? ???????.";
}

export function buildHintState(
  detections = [],
  frameWidth = 640,
  frameHeight = 640
) {
  const normalized =
    normalizeDetections(
      detections,
      frameWidth,
      frameHeight
    );

  const mainObstacle =
    pickMainObstacle(
      normalized
    );

  if (!mainObstacle) {
    return {
      level: "safe",
      text:
        "???? ??????? ????????.",
      shouldSpeak: false,
      forceInterrupt: false,
      debug: {
        total:
          detections.length,
        filtered:
          normalized.length,
        mainObstacle: null
      }
    };
  }

  const isDoor =
    mainObstacle.label ===
    "door";

  const isFurniture =
    mainObstacle.lowPriority;

  const isCritical =
    mainObstacle.label ===
      "stairs" ||
    mainObstacle.label ===
      "person" ||
    mainObstacle.label ===
      "obstacle";

  return {
    level:
      isCritical
        ? "warning"
        : "info",

    text:
      getHintText(
        mainObstacle
      ),

    shouldSpeak:
      isCritical,

    forceInterrupt:
      mainObstacle.label ===
      "stairs",

    debug: {
      total:
        detections.length,
      filtered:
        normalized.length,
      mainObstacle,
      isDoor,
      isFurniture
    }
  };
}
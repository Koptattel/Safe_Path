﻿const ort = window.ort;

const MODEL_URL =
  "./models/best.onnx";

const INPUT_SIZE = 640;

const DOOR_SCORE_THRESHOLD = 0.40;
const STAIRS_SCORE_THRESHOLD = 0.40;

const IOU_THRESHOLD = 0.45;

const CLASS_NAMES = [
  "door-closed",
  "door-half-open",
  "door-open",
  "stairs"
];

let session = null;
let ready = false;

let offscreenCanvas = null;
let offscreenCtx = null;

let lastVideoTime = -1;
let lastResult = null;

function ensureCanvas() {
  if (!offscreenCanvas) {
    offscreenCanvas =
      document.createElement(
        "canvas"
      );

    offscreenCtx =
      offscreenCanvas.getContext(
        "2d",
        {
          willReadFrequently: true
        }
      );
  }

  offscreenCanvas.width =
    INPUT_SIZE;

  offscreenCanvas.height =
    INPUT_SIZE;
}

function clamp(
  value,
  min,
  max
) {
  return Math.max(
    min,
    Math.min(max, value)
  );
}

function sigmoid(value) {
  return 1 / (
    1 + Math.exp(-value)
  );
}

function getScoreThreshold(
  label
) {
  if (
    label === "door-closed" ||
    label === "door-half-open" ||
    label === "door-open"
  ) {
    return DOOR_SCORE_THRESHOLD;
  }

  if (
    label === "stairs"
  ) {
    return STAIRS_SCORE_THRESHOLD;
  }

  return DOOR_SCORE_THRESHOLD;
}

function getIoU(
  boxA,
  boxB
) {
  const ax1 = boxA.x;
  const ay1 = boxA.y;
  const ax2 =
    boxA.x + boxA.width;
  const ay2 =
    boxA.y + boxA.height;

  const bx1 = boxB.x;
  const by1 = boxB.y;
  const bx2 =
    boxB.x + boxB.width;
  const by2 =
    boxB.y + boxB.height;

  const intersectionX1 =
    Math.max(ax1, bx1);

  const intersectionY1 =
    Math.max(ay1, by1);

  const intersectionX2 =
    Math.min(ax2, bx2);

  const intersectionY2 =
    Math.min(ay2, by2);

  const intersectionWidth =
    Math.max(
      0,
      intersectionX2 -
        intersectionX1
    );

  const intersectionHeight =
    Math.max(
      0,
      intersectionY2 -
        intersectionY1
    );

  const intersectionArea =
    intersectionWidth *
    intersectionHeight;

  const areaA =
    Math.max(0, boxA.width) *
    Math.max(0, boxA.height);

  const areaB =
    Math.max(0, boxB.width) *
    Math.max(0, boxB.height);

  const union =
    areaA +
    areaB -
    intersectionArea;

  if (union <= 0) {
    return 0;
  }

  return (
    intersectionArea / union
  );
}

function nonMaxSuppression(
  detections,
  iouThreshold = IOU_THRESHOLD
) {
  const sorted =
    [...detections].sort(
      (a, b) =>
        b.score - a.score
    );

  const selected = [];

  while (
    sorted.length > 0
  ) {
    const current =
      sorted.shift();

    selected.push(current);

    for (
      let index =
        sorted.length - 1;
      index >= 0;
      index -= 1
    ) {
      const candidate =
        sorted[index];

      const sameClass =
        candidate.classId ===
        current.classId;

      const overlapping =
        getIoU(
          candidate.box,
          current.box
        ) > iouThreshold;

      if (
        sameClass &&
        overlapping
      ) {
        sorted.splice(
          index,
          1
        );
      }
    }
  }

  return selected;
}

function prepareInput(
  videoEl
) {
  const videoWidth =
    videoEl.videoWidth ||
    INPUT_SIZE;

  const videoHeight =
    videoEl.videoHeight ||
    INPUT_SIZE;

  ensureCanvas();

  offscreenCtx.fillStyle =
    "rgb(114, 114, 114)";

  offscreenCtx.fillRect(
    0,
    0,
    INPUT_SIZE,
    INPUT_SIZE
  );

  const gain = Math.min(
    INPUT_SIZE / videoWidth,
    INPUT_SIZE / videoHeight
  );

  const resizedWidth =
    Math.round(
      videoWidth * gain
    );

  const resizedHeight =
    Math.round(
      videoHeight * gain
    );

  const padX =
    (INPUT_SIZE -
      resizedWidth) /
    2;

  const padY =
    (INPUT_SIZE -
      resizedHeight) /
    2;

  offscreenCtx.drawImage(
    videoEl,
    0,
    0,
    videoWidth,
    videoHeight,
    padX,
    padY,
    resizedWidth,
    resizedHeight
  );

  const imageData =
    offscreenCtx.getImageData(
      0,
      0,
      INPUT_SIZE,
      INPUT_SIZE
    );

  const pixels =
    imageData.data;

  const planeSize =
    INPUT_SIZE *
    INPUT_SIZE;

  const floatData =
    new Float32Array(
      planeSize * 3
    );

  for (
    let y = 0;
    y < INPUT_SIZE;
    y += 1
  ) {
    for (
      let x = 0;
      x < INPUT_SIZE;
      x += 1
    ) {
      const pixelIndex =
        (y * INPUT_SIZE + x) *
        4;

      const tensorIndex =
        y * INPUT_SIZE + x;

      floatData[
        tensorIndex
      ] =
        pixels[pixelIndex] /
        255;

      floatData[
        planeSize +
        tensorIndex
      ] =
        pixels[pixelIndex + 1] /
        255;

      floatData[
        planeSize * 2 +
        tensorIndex
      ] =
        pixels[pixelIndex + 2] /
        255;
    }
  }

  return {
    tensor: new ort.Tensor(
      "float32",
      floatData,
      [
        1,
        3,
        INPUT_SIZE,
        INPUT_SIZE
      ]
    ),

    meta: {
      videoWidth,
      videoHeight,
      gain,
      padX,
      padY
    }
  };
}

function createAccessor(
  dims,
  data
) {
  const expectedChannels =
    4 + CLASS_NAMES.length;

  if (
    dims.length === 3 &&
    dims[0] === 1
  ) {
    if (
      dims[1] ===
      expectedChannels
    ) {
      const channels =
        dims[1];

      const rows =
        dims[2];

      return {
        rows,
        channels,

        get(row, column) {
          return data[
            column * rows + row
          ];
        }
      };
    }

    if (
      dims[2] ===
      expectedChannels
    ) {
      const rows =
        dims[1];

      const channels =
        dims[2];

      return {
        rows,
        channels,

        get(row, column) {
          return data[
            row * channels +
            column
          ];
        }
      };
    }
  }

  if (
    dims.length === 2
  ) {
    if (
      dims[0] ===
      expectedChannels
    ) {
      const channels =
        dims[0];

      const rows =
        dims[1];

      return {
        rows,
        channels,

        get(row, column) {
          return data[
            column * rows + row
          ];
        }
      };
    }

    if (
      dims[1] ===
      expectedChannels
    ) {
      const rows =
        dims[0];

      const channels =
        dims[1];

      return {
        rows,
        channels,

        get(row, column) {
          return data[
            row * channels +
            column
          ];
        }
      };
    }
  }

  return null;
}

function decodeYoloOutput(
  outputTensor,
  meta
) {
  const dims =
    outputTensor.dims || [];

  const data =
    outputTensor.data;

  const accessor =
    createAccessor(
      dims,
      data
    );

  console.log(
    "ONNX output dims:",
    dims
  );

  if (!accessor) {
    console.warn(
      "Неподдерживаемый формат выхода ONNX:",
      dims
    );

    return [];
  }

  const {
    videoWidth,
    videoHeight,
    gain,
    padX,
    padY
  } = meta;

  const detections = [];

  for (
    let row = 0;
    row < accessor.rows;
    row += 1
  ) {
    const centerX =
      Number(
        accessor.get(row, 0)
      );

    const centerY =
      Number(
        accessor.get(row, 1)
      );

    const boxWidth =
      Number(
        accessor.get(row, 2)
      );

    const boxHeight =
      Number(
        accessor.get(row, 3)
      );

    if (
      !Number.isFinite(
        centerX
      ) ||
      !Number.isFinite(
        centerY
      ) ||
      !Number.isFinite(
        boxWidth
      ) ||
      !Number.isFinite(
        boxHeight
      )
    ) {
      continue;
    }

    let bestClassId = -1;
    let bestRawScore =
      -Infinity;

    for (
      let classId = 0;
      classId < CLASS_NAMES.length;
      classId += 1
    ) {
      const rawScore =
        Number(
          accessor.get(
            row,
            4 + classId
          )
        );

      if (
        rawScore >
        bestRawScore
      ) {
        bestRawScore =
          rawScore;

        bestClassId =
          classId;
      }
    }

    if (
      bestClassId < 0
    ) {
      continue;
    }

    const label =
      CLASS_NAMES[bestClassId];

    const score =
      bestRawScore >= 0 &&
      bestRawScore <= 1
        ? bestRawScore
        : sigmoid(
            bestRawScore
          );

    const threshold =
      getScoreThreshold(
        label
      );

    if (
      score < threshold
    ) {
      continue;
    }

    const x1 =
      (
        centerX -
        boxWidth / 2 -
        padX
      ) / gain;

    const y1 =
      (
        centerY -
        boxHeight / 2 -
        padY
      ) / gain;

    const x2 =
      (
        centerX +
        boxWidth / 2 -
        padX
      ) / gain;

    const y2 =
      (
        centerY +
        boxHeight / 2 -
        padY
      ) / gain;

    const left =
      clamp(
        x1,
        0,
        videoWidth
      );

    const top =
      clamp(
        y1,
        0,
        videoHeight
      );

    const right =
      clamp(
        x2,
        0,
        videoWidth
      );

    const bottom =
      clamp(
        y2,
        0,
        videoHeight
      );

    const width =
      right - left;

    const height =
      bottom - top;

    if (
      width <= 1 ||
      height <= 1
    ) {
      continue;
    }

    detections.push({
      classId: bestClassId,
      label,
      rawLabel: label,
      score,
      source: "custom",
      box: {
        x: left,
        y: top,
        width,
        height
      }
    });
  }

  return nonMaxSuppression(
    detections
  );
}

function decodeOutputs(
  results,
  meta
) {
  const outputNames =
    Object.keys(results);

  if (
    outputNames.length === 0
  ) {
    return [];
  }

  const output =
    results[outputNames[0]];

  if (!output) {
    return [];
  }

  console.log(
    "ONNX output names:",
    outputNames
  );

  return decodeYoloOutput(
    output,
    meta
  );
}

export async function initCustomDetector(
  onStatus = () => {}
) {
  if (
    ready &&
    session
  ) {
    return session;
  }

  onStatus(
    "Загрузка модели дверей и лестниц..."
  );

  if (
    !ort ||
    !ort.InferenceSession ||
    !ort.Tensor
  ) {
    throw new Error(
      "ONNX Runtime Web не найден в window.ort."
    );
  }

  if (
    ort.env &&
    ort.env.wasm
  ) {
    ort.env.wasm.simd =
      true;

    ort.env.wasm.numThreads =
      1;
  }

  session =
    await ort.InferenceSession.create(
      MODEL_URL,
      {
        executionProviders: [
          "wasm"
        ],

        graphOptimizationLevel:
          "all"
      }
    );

  console.log(
    "ONNX input names:",
    session.inputNames
  );

  console.log(
    "ONNX output names:",
    session.outputNames
  );

  ready = true;

  onStatus(
    "Модель дверей и лестниц готова."
  );

  return session;
}

export async function detectObjects(
  videoEl
) {
  if (
    !ready ||
    !session
  ) {
    return null;
  }

  if (
    !videoEl ||
    !videoEl.videoWidth ||
    !videoEl.videoHeight
  ) {
    return null;
  }

  if (
    videoEl.currentTime ===
      lastVideoTime &&
    lastResult
  ) {
    return lastResult;
  }

  const {
    tensor,
    meta
  } = prepareInput(
    videoEl
  );

  const inputName =
    session.inputNames[0];

  const results =
    await session.run({
      [inputName]: tensor
    });

  const detections =
    decodeOutputs(
      results,
      meta
    );

  lastVideoTime =
    videoEl.currentTime;

  lastResult =
    detections;

  console.log(
    "Custom YOLO detections:",
    detections
  );

  return detections;
}

export function resetCustomDetectorState() {
  lastVideoTime = -1;
  lastResult = null;
}

export function isCustomDetectorReady() {
  return (
    ready &&
    Boolean(session)
  );
}

export async function disposeCustomDetector() {
  resetCustomDetectorState();

  if (
    session &&
    typeof session.release ===
      "function"
  ) {
    try {
      await session.release();
    } catch (error) {
      console.warn(
        "Не удалось освободить ONNX-сессию:",
        error
      );
    }
  }

  session = null;
  ready = false;
}
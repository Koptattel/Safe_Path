﻿import {
  initMediaPipeDetector,
  detectObjects as detectMediaPipeObjects,
  resetMediaPipeDetectorState,
  isMediaPipeDetectorReady,
  disposeMediaPipeDetector
} from "./mediapipe-detector.js";

import {
  initSegFormerDetector,
  detectObjects as detectSegFormerObjects,
  resetSegFormerDetectorState,
  isSegFormerDetectorReady,
  disposeSegFormerDetector
} from "./segformer-detector.js";

let currentEngine =
  "main-spatial";

let inferenceBusy =
  false;

function isTwoLayerEngine() {
  return (
    currentEngine === "main-spatial" ||
    currentEngine === "two-layer"
  );
}

export function setDetectorEngine(
  engine
) {
  const allowed = [
    "mediapipe",
    "segformer",
    "main-spatial",
    "two-layer"
  ];

  if (!allowed.includes(engine)) {
    throw new Error(
      "Неизвестный режим распознавания: " +
      engine
    );
  }

  currentEngine =
    engine;
}

export function getDetectorEngine() {
  return currentEngine;
}

export async function initDetector(
  onStatus = () => {}
) {
  if (
    currentEngine ===
    "mediapipe"
  ) {
    await initMediaPipeDetector(
      onStatus
    );

    return true;
  }

  if (
    currentEngine ===
    "segformer"
  ) {
    await initSegFormerDetector(
      onStatus
    );

    return true;
  }

  if (isTwoLayerEngine()) {
    onStatus(
      "Загрузка SegFormer и MediaPipe..."
    );

    await initSegFormerDetector(
      onStatus
    );

    await initMediaPipeDetector(
      onStatus
    );

    onStatus(
      "SegFormer и MediaPipe готовы."
    );

    return true;
  }

  return false;
}

async function safeDetect(
  detectorFunction,
  videoEl,
  source
) {
  try {
    const detections =
      await detectorFunction(
        videoEl
      );

    if (
      !Array.isArray(detections)
    ) {
      return [];
    }

    return detections.map(
      (item) => ({
        ...item,
        source:
          item.source || source
      })
    );
  } catch (error) {
    console.error(
      "Ошибка детектора: " +
      source,
      error
    );

    return [];
  }
}

export async function detectObjects(
  videoEl
) {
  if (inferenceBusy) {
    return [];
  }

  inferenceBusy =
    true;

  try {
    if (
      currentEngine ===
      "mediapipe"
    ) {
      return await safeDetect(
        detectMediaPipeObjects,
        videoEl,
        "mediapipe"
      );
    }

    if (
      currentEngine ===
      "segformer"
    ) {
      return await safeDetect(
        detectSegFormerObjects,
        videoEl,
        "segformer"
      );
    }

    if (isTwoLayerEngine()) {
      const spatialDetections =
        isSegFormerDetectorReady()
          ? await safeDetect(
              detectSegFormerObjects,
              videoEl,
              "segformer"
            )
          : [];

      const objectDetections =
        isMediaPipeDetectorReady()
          ? await safeDetect(
              detectMediaPipeObjects,
              videoEl,
              "mediapipe"
            )
          : [];

      return [
        ...spatialDetections,
        ...objectDetections
      ];
    }

    return [];
  } finally {
    inferenceBusy =
      false;
  }
}

export function resetDetectorState() {
  inferenceBusy =
    false;

  resetMediaPipeDetectorState();
  resetSegFormerDetectorState();
}

export function isDetectorReady() {
  if (
    currentEngine ===
    "mediapipe"
  ) {
    return isMediaPipeDetectorReady();
  }

  if (
    currentEngine ===
    "segformer"
  ) {
    return isSegFormerDetectorReady();
  }

  if (isTwoLayerEngine()) {
    return (
      isSegFormerDetectorReady() &&
      isMediaPipeDetectorReady()
    );
  }

  return false;
}

export async function disposeDetector() {
  await Promise.all([
    disposeMediaPipeDetector(),
    disposeSegFormerDetector()
  ]);
}
import onnx

model = onnx.load("app/models/best.onnx")

print("INPUTS")
for inp in model.graph.input:
    dims = []
    for d in inp.type.tensor_type.shape.dim:
        dims.append(d.dim_value if d.dim_value > 0 else d.dim_param)
    print(inp.name, dims)

print("\nOUTPUTS")
for out in model.graph.output:
    dims = []
    for d in out.type.tensor_type.shape.dim:
        dims.append(d.dim_value if d.dim_value > 0 else d.dim_param)
    print(out.name, dims)
﻿import {
  initMediaPipeDetector,
  detectObjects as detectMediaPipeObjects,
  resetMediaPipeDetectorState,
  isMediaPipeDetectorReady,
  disposeMediaPipeDetector
} from "./mediapipe-detector.js";

import {
  initCustomDetector,
  detectObjects as detectCustomObjects,
  resetCustomDetectorState,
  isCustomDetectorReady,
  disposeCustomDetector
} from "./custom-detector.js";

let currentEngine =
  "two-layer";

export function setDetectorEngine(
  engine
) {
  const allowed = [
    "mediapipe",
    "custom",
    "two-layer"
  ];

  if (!allowed.includes(engine)) {
    throw new Error(
      `??????????? ??????: ${engine}`
    );
  }

  currentEngine = engine;
}

export function getDetectorEngine() {
  return currentEngine;
}

export async function initDetector(
  onStatus = () => {}
) {
  if (
    currentEngine ===
    "mediapipe"
  ) {
    return initMediaPipeDetector(
      onStatus
    );
  }

  if (
    currentEngine ===
    "custom"
  ) {
    return initCustomDetector(
      onStatus
    );
  }

  onStatus(
    "???????? ??????????? ???????..."
  );

  await Promise.all([
    initMediaPipeDetector(
      onStatus
    ),
    initCustomDetector(
      onStatus
    )
  ]);

  onStatus(
    "??? ???? ??????."
  );

  return true;
}

async function safeDetect(
  detectorFunction,
  videoEl,
  source
) {
  try {
    const detections =
      await detectorFunction(
        videoEl
      );

    if (
      !Array.isArray(detections)
    ) {
      return [];
    }

    return detections.map(
      (item) => ({
        ...item,
        source:
          item.source || source
      })
    );
  } catch (error) {
    console.error(
      `?????? ${source}:`,
      error
    );

    return [];
  }
}

export async function detectObjects(
  videoEl
) {
  if (
    currentEngine ===
    "mediapipe"
  ) {
    return safeDetect(
      detectMediaPipeObjects,
      videoEl,
      "mediapipe"
    );
  }

  if (
    currentEngine ===
    "custom"
  ) {
    return safeDetect(
      detectCustomObjects,
      videoEl,
      "custom"
    );
  }

  const [
    mediaPipeDetections,
    customDetections
  ] = await Promise.all([
    isMediaPipeDetectorReady()
      ? safeDetect(
          detectMediaPipeObjects,
          videoEl,
          "mediapipe"
        )
      : Promise.resolve([]),

    isCustomDetectorReady()
      ? safeDetect(
          detectCustomObjects,
          videoEl,
          "custom"
        )
      : Promise.resolve([])
  ]);

  const combined = [
    ...mediaPipeDetections,
    ...customDetections
  ];

  console.log(
    "MediaPipe detections:",
    mediaPipeDetections
  );

  console.log(
    "YOLO door/stairs detections:",
    customDetections
  );

  console.log(
    "Combined detections:",
    combined
  );

  return combined;
}

export function resetDetectorState() {
  resetMediaPipeDetectorState();
  resetCustomDetectorState();
}

export function isDetectorReady() {
  if (
    currentEngine ===
    "mediapipe"
  ) {
    return isMediaPipeDetectorReady();
  }

  if (
    currentEngine ===
    "custom"
  ) {
    return isCustomDetectorReady();
  }

  return (
    isMediaPipeDetectorReady() &&
    isCustomDetectorReady()
  );
}

export async function disposeDetector() {
  await Promise.all([
    disposeMediaPipeDetector(),
    disposeCustomDetector()
  ]);
}
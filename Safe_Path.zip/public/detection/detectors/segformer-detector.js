﻿const ort = window.ort;

const MODEL_URL =
  "../../models/segformer-wall.onnx";

const INPUT_SIZE =
  224;

const WALL_CLASS_ID =
  0;

const FLOOR_CLASS_ID =
  3;

const CEILING_CLASS_ID =
  5;

const PERSON_CLASS_ID =
  12;

const DOOR_CLASS_ID =
  14;

const STAIRS_CLASS_ID =
  53;

const MIN_CLASS_SCORE =
  0.50;

const MIN_REGION_PIXELS =
  12;

const MAX_MASK_SIDE =
  128;

let session = null;
let ready = false;

let canvas = null;
let context = null;

let lastVideoTime = -1;
let lastResult = null;

function ensureCanvas() {
  if (!canvas) {
    canvas =
      document.createElement(
        "canvas"
      );

    context =
      canvas.getContext(
        "2d",
        {
          willReadFrequently: true
        }
      );
  }

  canvas.width =
    INPUT_SIZE;

  canvas.height =
    INPUT_SIZE;
}

function clamp(
  value,
  min,
  max
) {
  return Math.max(
    min,
    Math.min(max, value)
  );
}

function prepareInput(
  videoEl
) {
  ensureCanvas();

  const videoWidth =
    videoEl.videoWidth ||
    INPUT_SIZE;

  const videoHeight =
    videoEl.videoHeight ||
    INPUT_SIZE;

  const gain = Math.min(
    INPUT_SIZE / videoWidth,
    INPUT_SIZE / videoHeight
  );

  const resizedWidth =
    Math.round(
      videoWidth * gain
    );

  const resizedHeight =
    Math.round(
      videoHeight * gain
    );

  const padX =
    (INPUT_SIZE -
      resizedWidth) /
    2;

  const padY =
    (INPUT_SIZE -
      resizedHeight) /
    2;

  context.fillStyle =
    "rgb(114, 114, 114)";

  context.fillRect(
    0,
    0,
    INPUT_SIZE,
    INPUT_SIZE
  );

  context.drawImage(
    videoEl,
    0,
    0,
    videoWidth,
    videoHeight,
    padX,
    padY,
    resizedWidth,
    resizedHeight
  );

  const imageData =
    context.getImageData(
      0,
      0,
      INPUT_SIZE,
      INPUT_SIZE
    );

  const pixels =
    imageData.data;

  const planeSize =
    INPUT_SIZE *
    INPUT_SIZE;

  const data =
    new Float32Array(
      planeSize * 3
    );

  for (
    let y = 0;
    y < INPUT_SIZE;
    y += 1
  ) {
    for (
      let x = 0;
      x < INPUT_SIZE;
      x += 1
    ) {
      const pixelIndex =
        (y * INPUT_SIZE + x) *
        4;

      const tensorIndex =
        y * INPUT_SIZE + x;

      const red =
        pixels[pixelIndex] /
        255;

      const green =
        pixels[pixelIndex + 1] /
        255;

      const blue =
        pixels[pixelIndex + 2] /
        255;

      data[tensorIndex] =
        (red - 0.5) / 0.5;

      data[
        planeSize +
        tensorIndex
      ] =
        (green - 0.5) / 0.5;

      data[
        planeSize * 2 +
        tensorIndex
      ] =
        (blue - 0.5) / 0.5;
    }
  }

  return {
    tensor: new ort.Tensor(
      "float32",
      data,
      [
        1,
        3,
        INPUT_SIZE,
        INPUT_SIZE
      ]
    ),

    meta: {
      videoWidth,
      videoHeight,
      gain,
      padX,
      padY
    }
  };
}

function softmax(values) {
  let maxValue =
    -Infinity;

  for (
    const value of values
  ) {
    maxValue =
      Math.max(
        maxValue,
        value
      );
  }

  const exponentials =
    values.map(
      (value) =>
        Math.exp(
          value - maxValue
        )
    );

  const total =
    exponentials.reduce(
      (sum, value) =>
        sum + value,
      0
    );

  if (total <= 0) {
    return values.map(
      () => 0
    );
  }

  return exponentials.map(
    (value) =>
      value / total
  );
}

function getOutputLayout(
  output
) {
  const dims =
    output.dims || [];

  if (dims.length !== 4) {
    throw new Error(
      "SegFormer вернул неподдерживаемую размерность выхода."
    );
  }

  let layout;
  let channels;
  let height;
  let width;

  if (
    dims[1] > dims[2] &&
    dims[1] > dims[3]
  ) {
    layout =
      "nchw";

    channels =
      dims[1];

    height =
      dims[2];

    width =
      dims[3];
  } else if (
    dims[3] > dims[1] &&
    dims[3] > dims[2]
  ) {
    layout =
      "nhwc";

    height =
      dims[1];

    width =
      dims[2];

    channels =
      dims[3];
  } else {
    throw new Error(
      "Не удалось определить расположение каналов SegFormer: " +
      dims.join("x")
    );
  }

  return {
    dims,
    layout,
    channels,
    height,
    width
  };
}

function getLogit(
  data,
  layout,
  channels,
  height,
  width,
  classId,
  y,
  x
) {
  const pixelIndex =
    y * width + x;

  if (
    layout === "nchw"
  ) {
    return data[
      classId * height * width +
      pixelIndex
    ];
  }

  return data[
    pixelIndex * channels +
    classId
  ];
}

function resizeMask(
  mask,
  sourceWidth,
  sourceHeight
) {
  const targetWidth =
    Math.min(
      sourceWidth,
      MAX_MASK_SIDE
    );

  const targetHeight =
    Math.min(
      sourceHeight,
      MAX_MASK_SIDE
    );

  if (
    targetWidth === sourceWidth &&
    targetHeight === sourceHeight
  ) {
    return {
      width: sourceWidth,
      height: sourceHeight,
      values: mask
    };
  }

  const values =
    new Uint8Array(
      targetWidth *
      targetHeight
    );

  for (
    let y = 0;
    y < targetHeight;
    y += 1
  ) {
    for (
      let x = 0;
      x < targetWidth;
      x += 1
    ) {
      const sourceX =
        Math.floor(
          x *
          sourceWidth /
          targetWidth
        );

      const sourceY =
        Math.floor(
          y *
          sourceHeight /
          targetHeight
        );

      values[
        y * targetWidth + x
      ] =
        mask[
          sourceY *
            sourceWidth +
          sourceX
        ];
    }
  }

  return {
    width: targetWidth,
    height: targetHeight,
    values
  };
}

function createRegionBox(
  mask,
  scores,
  width,
  height,
  videoWidth,
  videoHeight,
  classId,
  label,
  source
) {
  let minX =
    width;

  let minY =
    height;

  let maxX =
    -1;

  let maxY =
    -1;

  let pixels =
    0;

  let scoreSum =
    0;

  for (
    let y = 0;
    y < height;
    y += 1
  ) {
    for (
      let x = 0;
      x < width;
      x += 1
    ) {
      const index =
        y * width + x;

      if (!mask[index]) {
        continue;
      }

      minX =
        Math.min(
          minX,
          x
        );

      minY =
        Math.min(
          minY,
          y
        );

      maxX =
        Math.max(
          maxX,
          x
        );

      maxY =
        Math.max(
          maxY,
          y
        );

      pixels += 1;

      scoreSum +=
        scores[index];
    }
  }

  if (
    pixels <
      MIN_REGION_PIXELS ||
    maxX < 0
  ) {
    return null;
  }

  const x =
    minX /
    width *
    videoWidth;

  const y =
    minY /
    height *
    videoHeight;

  const right =
    (maxX + 1) /
    width *
    videoWidth;

  const bottom =
    (maxY + 1) /
    height *
    videoHeight;

  const boxWidth =
    right - x;

  const boxHeight =
    bottom - y;

  if (
    boxWidth <= 1 ||
    boxHeight <= 1
  ) {
    return null;
  }

  return {
    classId,
    label,
    rawLabel: label,
    score:
      scoreSum / pixels,
    source,
    box: {
      x: clamp(
        x,
        0,
        videoWidth
      ),

      y: clamp(
        y,
        0,
        videoHeight
      ),

      width: boxWidth,
      height: boxHeight
    },

    segmentation: {
      width,
      height,
      pixels
    }
  };
}

function decodeOutput(
  output,
  meta
) {
  const layout =
    getOutputLayout(
      output
    );

  const {
    channels,
    height,
    width
  } = layout;

  const classIds = [
    WALL_CLASS_ID,
    FLOOR_CLASS_ID,
    CEILING_CLASS_ID,
    PERSON_CLASS_ID,
    DOOR_CLASS_ID,
    STAIRS_CLASS_ID
  ];

  const labels = {
    [WALL_CLASS_ID]:
      "wall",

    [FLOOR_CLASS_ID]:
      "floor",

    [CEILING_CLASS_ID]:
      "ceiling",

    [PERSON_CLASS_ID]:
      "person",

    [DOOR_CLASS_ID]:
      "door",

    [STAIRS_CLASS_ID]:
      "stairs"
  };

  const masks = {};
  const scores = {};

  for (
    const classId of classIds
  ) {
    if (
      classId >= channels
    ) {
      continue;
    }

    masks[classId] =
      new Uint8Array(
        width * height
      );

    scores[classId] =
      new Float32Array(
        width * height
      );
  }

  for (
    let y = 0;
    y < height;
    y += 1
  ) {
    for (
      let x = 0;
      x < width;
      x += 1
    ) {
      const logits =
        new Array(
          channels
        );

      for (
        let classId = 0;
        classId < channels;
        classId += 1
      ) {
        logits[classId] =
          Number(
            getLogit(
              output.data,
              layout.layout,
              channels,
              height,
              width,
              classId,
              y,
              x
            )
          );
      }

      const probabilities =
        softmax(
          logits
        );

      let bestClassId =
        -1;

      let bestScore =
        0;

      for (
        const classId of classIds
      ) {
        if (
          classId >=
          probabilities.length
        ) {
          continue;
        }

        if (
          probabilities[classId] >
          bestScore
        ) {
          bestClassId =
            classId;

          bestScore =
            probabilities[classId];
        }
      }

      const index =
        y * width + x;

      if (
        bestClassId >= 0 &&
        masks[bestClassId] &&
        bestScore >=
          MIN_CLASS_SCORE
      ) {
        masks[bestClassId][index] =
          1;

        scores[bestClassId][index] =
          bestScore;
      }
    }
  }

  const detections = [];

  for (
    const classId of classIds
  ) {
    if (
      !masks[classId]
    ) {
      continue;
    }

    const region =
      createRegionBox(
        masks[classId],
        scores[classId],
        width,
        height,
        meta.videoWidth,
        meta.videoHeight,
        classId,
        labels[classId],
        "segformer"
      );

    if (region) {
      detections.push(
        region
      );
    }
  }

  console.log(
    "SegFormer output:",
    layout.dims,
    "layout:",
    layout.layout,
    "detections:",
    detections
  );

  return detections;
}

export async function initSegFormerDetector(
  onStatus = () => {}
) {
  if (
    ready &&
    session
  ) {
    return session;
  }

  if (
    !ort ||
    !ort.InferenceSession ||
    !ort.Tensor
  ) {
    throw new Error(
      "ONNX Runtime Web не подключён."
    );
  }

  onStatus(
    "Проверка SegFormer..."
  );

  if (
    ort.env &&
    ort.env.wasm
  ) {
    ort.env.wasm.simd =
      true;

    ort.env.wasm.numThreads =
      1;
  }

  session =
    await ort.InferenceSession.create(
      MODEL_URL,
      {
        executionProviders: [
          "wasm"
        ],

        graphOptimizationLevel:
          "all"
      }
    );

  console.log(
    "SegFormer input names:",
    session.inputNames
  );

  console.log(
    "SegFormer output names:",
    session.outputNames
  );

  ready =
    true;

  onStatus(
    "SegFormer готов."
  );

  return session;
}

export async function detectObjects(
  videoEl
) {
  if (
    !ready ||
    !session
  ) {
    return null;
  }

  if (
    !videoEl ||
    !videoEl.videoWidth ||
    !videoEl.videoHeight
  ) {
    return null;
  }

  if (
    videoEl.currentTime ===
      lastVideoTime &&
    lastResult
  ) {
    return lastResult;
  }

  const {
    tensor,
    meta
  } = prepareInput(
    videoEl
  );

  const inputName =
    session.inputNames[0];

  const results =
    await session.run({
      [inputName]:
        tensor
    });

  const outputName =
    session.outputNames[0];

  const output =
    results[outputName];

  if (!output) {
    throw new Error(
      "SegFormer не вернул выходной тензор."
    );
  }

  const detections =
    decodeOutput(
      output,
      meta
    );

  lastVideoTime =
    videoEl.currentTime;

  lastResult =
    detections;

  return detections;
}

export function resetSegFormerDetectorState() {
  lastVideoTime =
    -1;

  lastResult =
    null;
}

export function isSegFormerDetectorReady() {
  return (
    ready &&
    Boolean(session)
  );
}

export async function disposeSegFormerDetector() {
  resetSegFormerDetectorState();

  if (
    session &&
    typeof session.release ===
      "function"
  ) {
    try {
      await session.release();
    } catch (error) {
      console.warn(
        "Не удалось освободить сессию SegFormer:",
        error
      );
    }
  }

  session =
    null;

  ready =
    false;
}
﻿import {
  FilesetResolver,
  ObjectDetector
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

const WASM_URL =
  "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";

const MODEL_URL =
  "https://storage.googleapis.com/mediapipe-tasks/object_detector/efficientdet_lite0_uint8.tflite";

const SCORE_THRESHOLD =
  0.30;

const MAX_RESULTS =
  20;

let detector =
  null;

let ready =
  false;

let lastVideoTime =
  -1;

let lastResult =
  null;

function normalizeDetection(
  detection
) {
  const category =
    detection?.categories?.[0];

  const sourceBox =
    detection?.boundingBox;

  if (
    !category ||
    !sourceBox
  ) {
    return null;
  }

  const x =
    Number(sourceBox.originX);

  const y =
    Number(sourceBox.originY);

  const width =
    Number(sourceBox.width);

  const height =
    Number(sourceBox.height);

  if (
    !Number.isFinite(x) ||
    !Number.isFinite(y) ||
    !Number.isFinite(width) ||
    !Number.isFinite(height) ||
    width <= 0 ||
    height <= 0
  ) {
    return null;
  }

  return {
    label:
      String(
        category.categoryName ||
        category.displayName ||
        "unknown"
      )
        .trim()
        .toLowerCase(),

    rawLabel:
      String(
        category.categoryName ||
        category.displayName ||
        "unknown"
      )
        .trim()
        .toLowerCase(),

    score:
      Math.max(
        0,
        Math.min(
          1,
          Number(category.score || 0)
        )
      ),

    source:
      "mediapipe",

    box: {
      x,
      y,
      width,
      height
    }
  };
}

function normalizeMediaPipeDetections(
  result
) {
  if (
    !result ||
    !Array.isArray(
      result.detections
    )
  ) {
    return [];
  }

  return result.detections
    .map(normalizeDetection)
    .filter(Boolean)
    .filter(
      (item) =>
        item.score >=
        SCORE_THRESHOLD
    );
}

export async function initMediaPipeDetector(
  onStatus = () => {}
) {
  if (
    ready &&
    detector
  ) {
    return detector;
  }

  onStatus(
    "Загрузка MediaPipe..."
  );

  const vision =
    await FilesetResolver.forVisionTasks(
      WASM_URL
    );

  onStatus(
    "Загрузка модели EfficientDet..."
  );

  detector =
    await ObjectDetector.createFromOptions(
      vision,
      {
        baseOptions: {
          modelAssetPath:
            MODEL_URL
        },

        runningMode:
          "VIDEO",

        scoreThreshold:
          SCORE_THRESHOLD,

        maxResults:
          MAX_RESULTS
      }
    );

  ready =
    true;

  onStatus(
    "MediaPipe готов."
  );

  return detector;
}

export async function detectObjects(
  videoEl
) {
  if (
    !ready ||
    !detector
  ) {
    return null;
  }

  if (
    !videoEl ||
    !videoEl.videoWidth ||
    !videoEl.videoHeight
  ) {
    return null;
  }

  const currentTime =
    Number(videoEl.currentTime);

  if (
    Number.isFinite(currentTime) &&
    currentTime === lastVideoTime &&
    lastResult
  ) {
    return lastResult;
  }

  const result =
    detector.detectForVideo(
      videoEl,
      performance.now()
    );

  const detections =
    normalizeMediaPipeDetections(
      result
    );

  lastVideoTime =
    currentTime;

  lastResult =
    detections;

  console.log(
    "MediaPipe detections:",
    detections
  );

  return detections;
}

export function resetMediaPipeDetectorState() {
  lastVideoTime =
    -1;

  lastResult =
    null;
}

export function isMediaPipeDetectorReady() {
  return (
    ready &&
    Boolean(detector)
  );
}

export async function disposeMediaPipeDetector() {
  resetMediaPipeDetectorState();

  if (
    detector &&
    typeof detector.close ===
      "function"
  ) {
    detector.close();
  }

  detector =
    null;

  ready =
    false;
}
﻿export {
  initDetector,
  detectObjects,
  resetDetectorState,
  isDetectorReady,
  disposeDetector,
  setDetectorEngine,
  getDetectorEngine
} from "./detectors/detector-manager.js";
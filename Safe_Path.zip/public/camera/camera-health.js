﻿export function getCameraStream(video) {
  if (
    !video
  ) {
    return null;
  }

  return (
    video.srcObject ||
    null
  );
}

export function getCameraTrack(video) {
  const stream =
    getCameraStream(video);

  if (
    !stream ||
    typeof stream.getVideoTracks !==
      "function"
  ) {
    return null;
  }

  const tracks =
    stream.getVideoTracks();

  return tracks.find(
    track =>
      track.readyState ===
      "live"
  ) || null;
}

export function isCameraStreamActive(
  video
) {
  const track =
    getCameraTrack(video);

  if (
    !track
  ) {
    return false;
  }

  return (
    track.readyState === "live" &&
    !track.muted
  );
}

export function isCameraReady(
  video
) {
  if (
    !video
  ) {
    return false;
  }

  if (
    !isCameraStreamActive(video)
  ) {
    return false;
  }

  if (
    video.readyState <
    HTMLMediaElement.HAVE_CURRENT_DATA
  ) {
    return false;
  }

  if (
    !video.videoWidth ||
    !video.videoHeight
  ) {
    return false;
  }

  if (
    video.paused ||
    video.ended
  ) {
    return false;
  }

  return true;
}

export function getCameraStatus(
  video
) {
  if (
    !video
  ) {
    return {
      ready: false,
      code: "VIDEO_ELEMENT_MISSING",
      message: "Элемент камеры не найден."
    };
  }

  const stream =
    getCameraStream(video);

  if (
    !stream
  ) {
    return {
      ready: false,
      code: "STREAM_MISSING",
      message: "Камера не подключена."
    };
  }

  const track =
    getCameraTrack(video);

  if (
    !track
  ) {
    return {
      ready: false,
      code: "VIDEO_TRACK_MISSING",
      message: "Видеотрек камеры отсутствует."
    };
  }

  if (
    track.readyState !== "live"
  ) {
    return {
      ready: false,
      code: "TRACK_NOT_LIVE",
      message: "Камера остановлена."
    };
  }

  if (
    video.readyState <
    HTMLMediaElement.HAVE_CURRENT_DATA
  ) {
    return {
      ready: false,
      code: "VIDEO_DATA_NOT_READY",
      message: "Камера не передаёт изображение."
    };
  }

  if (
    !video.videoWidth ||
    !video.videoHeight
  ) {
    return {
      ready: false,
      code: "VIDEO_DIMENSIONS_MISSING",
      message: "Изображение с камеры пустое."
    };
  }

  if (
    video.paused ||
    video.ended
  ) {
    return {
      ready: false,
      code: "VIDEO_PAUSED",
      message: "Видеопоток камеры приостановлен."
    };
  }

  return {
    ready: true,
    code: "OK",
    message: "Камера работает.",
    width: video.videoWidth,
    height: video.videoHeight
  };
}

export function installCameraHealthListeners(
  video,
  onChange = () => {}
) {
  if (
    !video
  ) {
    return () => {};
  }

  const events = [
    "loadedmetadata",
    "canplay",
    "playing",
    "pause",
    "ended",
    "error",
    "stalled",
    "emptied"
  ];

  const handler = () => {
    onChange(
      getCameraStatus(video)
    );
  };

  events.forEach(
    event =>
      video.addEventListener(
        event,
        handler
      )
  );

  const timer =
    window.setInterval(
      handler,
      1000
    );

  return () => {
    events.forEach(
      event =>
        video.removeEventListener(
          event,
          handler
        )
    );

    window.clearInterval(timer);
  };
}

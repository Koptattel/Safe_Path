﻿function getCameraErrorMessage(error) {
  if (!error) {
    return "Не удалось запустить камеру.";
  }

  if (error.name === "NotAllowedError") {
    return "Доступ к камере запрещён. Разрешите камеру в настройках Android.";
  }

  if (error.name === "NotFoundError") {
    return "Камера не найдена на устройстве.";
  }

  if (error.name === "NotReadableError") {
    return "Камера занята другим приложением.";
  }

  if (error.name === "OverconstrainedError") {
    return "Параметры камеры не поддерживаются.";
  }

  if (error.name === "SecurityError") {
    return "Доступ к камере заблокирован политикой безопасности.";
  }

  return "Не удалось запустить камеру.";
}

export function isCameraSupported() {
  return Boolean(
    navigator.mediaDevices &&
    navigator.mediaDevices.getUserMedia
  );
}

export function isSecureCameraContext() {
  const protocol = window.location.protocol;

  return (
    protocol === "https:" ||
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1"
  );
}

export async function startCamera(
  videoEl,
  onStatus = () => {}
) {
  if (!isCameraSupported()) {
    const message =
      "Браузер не поддерживает доступ к камере.";

    onStatus(message);
    throw new Error(message);
  }

  if (!isSecureCameraContext()) {
    const message =
      "Камера доступна только через HTTPS или localhost.";

    onStatus(message);
    throw new Error(message);
  }

  onStatus("Запрашиваем доступ к камере...");

  try {
    const stream =
      await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: {
            ideal: "environment"
          },
          width: {
            ideal: 1280
          },
          height: {
            ideal: 720
          }
        },
        audio: false
      });

    videoEl.srcObject = stream;

    await videoEl.play();

    onStatus("Камера запущена.");

    return stream;
  } catch (error) {
    const message =
      getCameraErrorMessage(error);

    onStatus(message);

    throw new Error(message);
  }
}

export function isCameraRunning(videoEl) {
  const stream =
    videoEl?.srcObject;

  if (!stream) {
    return false;
  }

  return stream
    .getVideoTracks()
    .some(
      (track) =>
        track.readyState === "live"
    );
}

export function stopCamera(
  videoEl,
  onStatus = () => {}
) {
  const stream =
    videoEl?.srcObject;

  if (!stream) {
    onStatus("Камера уже остановлена.");
    return;
  }

  stream
    .getTracks()
    .forEach(
      (track) => track.stop()
    );

  videoEl.srcObject = null;

  onStatus("Камера остановлена.");
}
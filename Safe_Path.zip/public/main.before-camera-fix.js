
import {
  getCameraStatus
} from "./camera/camera-health.js";
import {
  startCamera,
  stopCamera,
  isCameraRunning
} from "./camera/index.js";

import {
  speak,
  stopSpeaking
} from "./speech/index.js";

import {
  createAppState
} from "./state/index.js";

import {
  getHintStateFromDetections,
  resetLogic
} from "./logic/index.js";

import {
  initDetector,
  detectObjects,
  resetDetectorState,
  isDetectorReady,
  disposeDetector,
  setDetectorEngine,
  getDetectorEngine
} from "./detection/index.js";

import {
  normalizeDetections
} from "./detection/utils/detection-normalize.js";

const statusEl =
  document.getElementById("status");

const statusModeEl =
  document.getElementById("statusMode");

const voiceOutputEl =
  document.getElementById("voiceOutput");

const startBtn =
  document.getElementById("startBtn");

const installBtn =
  document.getElementById("installBtn");

const videoEl =
  document.getElementById("video");

const overlayEl =
  document.getElementById("overlay");

const detectorModeEl =
  document.getElementById("detectorMode");

const detectorInfoEl =
  document.getElementById("detectorInfo");

const systemDetailsEl =
  document.getElementById("systemDetails");

const overlayCtx =
  overlayEl.getContext("2d");

const appState =
  createAppState();

let deferredInstallPrompt =
  null;

let isRunning =
  false;

let lastSpokenText =
  "";

let lastSpokenAt =
  0;

let lastStableState = {
  level: "safe",
  text: "Путь впереди свободен.",
  shouldSpeak: false,
  forceInterrupt: false,
  debug: {}
};

let dangerFrames =
  0;

let safeFrames =
  0;

const DANGER_CONFIRM_FRAMES =
  2;

const SAFE_CONFIRM_FRAMES =
  2;

const SPEECH_REPEAT_DELAY_MS =
  3500;

function engineTitle(
  engine
) {
  if (
    engine ===
    "main-spatial"
  ) {
    return "SegFormer + MediaPipe";
  }

  if (
    engine ===
    "segformer"
  ) {
    return "Только SegFormer";
  }

  if (
    engine ===
    "mediapipe"
  ) {
    return "Только MediaPipe";
  }

  return engine;
}

function engineDescription(
  engine
) {
  if (
    engine ===
    "main-spatial"
  ) {
    return (
      "SegFormer: стены, люди, двери и лестницы. " +
      "MediaPipe: типовые интерьерные объекты."
    );
  }

  if (
    engine ===
    "segformer"
  ) {
    return (
      "SegFormer: стены, люди, двери и лестницы."
    );
  }

  if (
    engine ===
    "mediapipe"
  ) {
    return (
      "MediaPipe: типовые объекты из набора COCO."
    );
  }

  return "";
}

function setStatus(
  mode,
  text
) {
  statusModeEl.textContent =
    mode;

  statusModeEl.className =
    "status-chip";

  if (
    mode === "Анализ"
  ) {
    statusModeEl.classList.add(
      "status-run"
    );
  } else if (
    mode === "Ошибка"
  ) {
    statusModeEl.classList.add(
      "status-alert"
    );
  } else {
    statusModeEl.classList.add(
      "status-wait"
    );
  }

  statusEl.textContent =
    text;

  appState.appMode =
    mode === "Подготовка"
      ? "preparing"
      : mode === "Анализ"
        ? "analyzing"
        : mode === "Ошибка"
          ? "error"
          : "idle";
}

function setVoiceText(
  text
) {
  voiceOutputEl.textContent =
    text ||
    "Нет активных подсказок.";

  appState.lastHintText =
    text || "";
}

function setSystemDetails(
  text
) {
  if (
    systemDetailsEl
  ) {
    systemDetailsEl.textContent =
      text;
  }
}

function updateDetectorInfo() {
  const engine =
    getDetectorEngine();

  detectorInfoEl.textContent =
    engineDescription(engine);

  detectorModeEl.value =
    engine;
}

function syncOverlaySize() {
  if (
    videoEl.videoWidth &&
    videoEl.videoHeight
  ) {
    overlayEl.width =
      videoEl.videoWidth;

    overlayEl.height =
      videoEl.videoHeight;

    return;
  }

  const rect =
    videoEl.getBoundingClientRect();

  overlayEl.width =
    Math.max(
      1,
      Math.round(rect.width)
    );

  overlayEl.height =
    Math.max(
      1,
      Math.round(rect.height)
    );
}

function clearOverlay() {
  overlayCtx.clearRect(
    0,
    0,
    overlayEl.width,
    overlayEl.height
  );
}

function labelText(
  item
) {
  const labels = {
    wall: "Стена",
    floor: "Пол",
    ceiling: "Потолок",
    person: "Человек",
    stairs: "Лестница",
    door: "Дверь",
    "door-closed": "Дверь закрыта",
    "door-half-open": "Дверь полуоткрыта",
    "door-open": "Дверь открыта",
    obstacle: "Препятствие",

    chair: "Стул",
    "dining table": "Стол",
    couch: "Диван",
    bed: "Кровать",
    bench: "Скамейка",
    "potted plant": "Растение",
    backpack: "Рюкзак",
    suitcase: "Чемодан",
    handbag: "Сумка",
    bottle: "Бутылка",
    cup: "Чашка",
    book: "Книга",
    laptop: "Ноутбук",
    "cell phone": "Телефон"
  };

  return (
    labels[item.label] ||
    item.label ||
    "Объект"
  );
}

function colorByLevel(
  level
) {
  if (
    level === "danger"
  ) {
    return "#cb4d5d";
  }

  if (
    level === "warning"
  ) {
    return "#d59a1a";
  }

  if (
    level === "info"
  ) {
    return "#00a7b3";
  }

  return "#2ea043";
}

function sameDetection(
  a,
  b
) {
  if (
    !a ||
    !b ||
    !a.box ||
    !b.box
  ) {
    return false;
  }

  return (
    a.label === b.label &&
    a.source === b.source &&
    Math.abs(
      a.box.x - b.box.x
    ) < 2 &&
    Math.abs(
      a.box.y - b.box.y
    ) < 2 &&
    Math.abs(
      a.box.width - b.box.width
    ) < 2 &&
    Math.abs(
      a.box.height - b.box.height
    ) < 2
  );
}

function drawDetections(
  detections,
  mainObstacle,
  level
) {
  clearOverlay();

  if (
    !Array.isArray(detections)
  ) {
    return;
  }

  overlayCtx.lineWidth =
    4;

  overlayCtx.font =
    "16px Arial";

  for (
    const item of detections
  ) {
    if (
      !item.box ||
      item.box.width <= 0 ||
      item.box.height <= 0
    ) {
      continue;
    }

    const {
      x,
      y,
      width,
      height
    } = item.box;

    const isMain =
      sameDetection(
        item,
        mainObstacle
      );

    let color =
      "#00a7b3";

    if (
      item.source ===
      "mediapipe"
    ) {
      color =
        "#9b59ff";
    }

    if (
      item.source ===
      "segformer"
    ) {
      color =
        "#00a7b3";
    }

    if (
      isMain
    ) {
      color =
        colorByLevel(level);
    }

    const text =
      `${labelText(item)} ` +
      `${Math.round(item.score * 100)}%`;

    overlayCtx.strokeStyle =
      color;

    overlayCtx.fillStyle =
      color;

    overlayCtx.strokeRect(
      x,
      y,
      width,
      height
    );

    const textWidth =
      overlayCtx.measureText(
        text
      ).width;

    const textY =
      y > 30
        ? y - 30
        : y + 4;

    overlayCtx.fillRect(
      x,
      textY,
      textWidth + 12,
      25
    );

    overlayCtx.fillStyle =
      "#ffffff";

    overlayCtx.fillText(
      text,
      x + 6,
      textY + 17
    );
  }
}

function cloneState(
  state
) {
  return {
    level:
      state?.level ||
      "safe",

    text:
      state?.text ||
      "Путь впереди свободен.",

    shouldSpeak:
      Boolean(
        state?.shouldSpeak
      ),

    forceInterrupt:
      Boolean(
        state?.forceInterrupt
      ),

    debug:
      state?.debug ||
      {}
  };
}

function stabilizeState(
  state
) {
  const candidate =
    cloneState(state);

  const dangerous =
    candidate.level === "danger" ||
    candidate.level === "warning";

  if (
    dangerous
  ) {
    dangerFrames += 1;
    safeFrames = 0;

    if (
      dangerFrames >=
      DANGER_CONFIRM_FRAMES
    ) {
      lastStableState =
        candidate;

      return lastStableState;
    }

    return {
      ...lastStableState,
      shouldSpeak: false,
      forceInterrupt: false
    };
  }

  safeFrames += 1;
  dangerFrames = 0;

  if (
    safeFrames >=
    SAFE_CONFIRM_FRAMES
  ) {
    lastStableState = {
      ...candidate,
      shouldSpeak: false,
      forceInterrupt: false
    };

    return lastStableState;
  }

  return {
    ...lastStableState,
    shouldSpeak: false,
    forceInterrupt: false
  };
}

function maybeSpeak(
  state
) {
  if (
    !state.shouldSpeak ||
    !state.text
  ) {
    return;
  }

  const now =
    Date.now();

  const changed =
    state.text !==
    lastSpokenText;

  const repeatedAllowed =
    now -
      lastSpokenAt >=
    SPEECH_REPEAT_DELAY_MS;

  if (
    !changed &&
    !repeatedAllowed &&
    !state.forceInterrupt
  ) {
    return;
  }

  if (
    state.forceInterrupt
  ) {
    stopSpeaking();
  }

  speak(
    state.text,
    {
      priority:
        state.level === "danger"
          ? "high"
          : "normal",

      rate:
        state.level === "danger"
          ? 1.02
          : 1,

      pitch: 1,
      volume: 1,

      interrupt:
        Boolean(
          state.forceInterrupt
        )
    }
  );

  lastSpokenText =
    state.text;

  lastSpokenAt =
    now;

  appState.lastSpokenAt =
    now;
}

function updateUi(
  state
) {
  appState.lastHintLevel =
    state.level;

  appState.lastMainObstacle =
    state.debug?.mainObstacle ||
    null;

  appState.lastDetectionsCount =
    state.debug?.total ||
    0;

  setVoiceText(
    state.text
  );

  if (
    state.level ===
    "danger"
  ) {
    setStatus(
      "Анализ",
      "Опасность впереди."
    );
  } else if (
    state.level ===
    "warning"
  ) {
    setStatus(
      "Анализ",
      "Впереди важный объект."
    );
  } else if (
    state.level ===
    "info"
  ) {
    setStatus(
      "Анализ",
      "Обстановка анализируется."
    );
  } else {
    setStatus(
      "Анализ",
      "Путь впереди свободен."
    );
  }
}

function debugText(
  state,
  rawDetections
) {
  const total =
    rawDetections?.length ||
    0;

  const filtered =
    state.debug?.filtered ||
    0;

  const main =
    state.debug?.mainObstacle;

  const mainText =
    main
      ? `${labelText(main)}, ` +
        `${Math.round(main.score * 100)}%, ` +
        `${
          main.source === "mediapipe"
            ? "MediaPipe"
            : "SegFormer"
        }`
      : "нет";

  return (
    `Детекций: ${total}. ` +
    `После фильтрации: ${filtered}. ` +
    `Главный объект: ${mainText}.`
  );
}

async function analysisLoop() {
  if (
    !isRunning
  ) {
    return;
  }

  try {
    const rawDetections =
      await detectObjects(
        videoEl
      );

    if (
      rawDetections === null
    ) {
      appState.analysisTimer =
        requestAnimationFrame(
          analysisLoop
        );

      return;
    }

    const frameWidth =
      videoEl.videoWidth ||
      640;

    const frameHeight =
      videoEl.videoHeight ||
      480;

    const detections =
      normalizeDetections(
        rawDetections,
        frameWidth,
        frameHeight
      );

    const rawState =
      getHintStateFromDetections(
        detections,
        frameWidth,
        frameHeight
      );

    const state =
      stabilizeState(
        rawState
      );

    const mainObstacle =
      state.debug?.mainObstacle ||
      rawState.debug?.mainObstacle ||
      null;

    drawDetections(
      detections,
      mainObstacle,
      state.level
    );

    updateUi(
      state
    );

    maybeSpeak(
      state
    );

    setSystemDetails(
      debugText(
        state,
        rawDetections
      )
    );
  } catch (
    error
  ) {
    console.error(
      "Ошибка анализа:",
      error
    );

    setStatus(
      "Ошибка",
      error.message ||
        "Ошибка анализа."
    );

    setVoiceText(
      "Анализ остановлен."
    );

    await stopApp();

    return;
  }

  appState.analysisTimer =
    requestAnimationFrame(
      analysisLoop
    );
}

function resetRuntimeState() {
  appState.cameraReady =
    false;

  appState.detectorReady =
    false;

  appState.lastHintText =
    "";

  appState.lastHintLevel =
    "safe";

  appState.lastMainObstacle =
    null;

  appState.lastDetectionsCount =
    0;

  resetLogic();
  resetDetectorState();

  dangerFrames =
    0;

  safeFrames =
    0;

  lastStableState = {
    level: "safe",
    text: "Путь впереди свободен.",
    shouldSpeak: false,
    forceInterrupt: false,
    debug: {}
  };

  lastSpokenText =
    "";

  lastSpokenAt =
    0;
}

async function startApp() {
  if (
    isRunning
  ) {
    return;
  }

  setStatus(
    "Подготовка",
    "Запуск камеры..."
  );

  setVoiceText(
    "Подготовка SegFormer и MediaPipe."
  );

  setSystemDetails(
    "Загрузка моделей и подготовка анализа..."
  );

  resetRuntimeState();
  clearOverlay();

  try {
    await startCamera(
      videoEl,
      (message) => {
        setStatus(
          "Подготовка",
          message
        );
      }
    );

    appState.cameraReady =
      true;

    await initDetector(
      (message) => {
        setStatus(
          "Подготовка",
          message
        );
      }
    );

    appState.detectorReady =
      isDetectorReady();

    if (
      !appState.detectorReady
    ) {
      throw new Error(
        "SegFormer и MediaPipe не готовы."
      );
    }

    syncOverlaySize();

    resetDetectorState();

    isRunning =
      true;

    startBtn.textContent =
      "Остановить";

    setStatus(
      "Анализ",
      "SegFormer и MediaPipe запущены."
    );

    setVoiceText(
      "Анализ начат."
    );

    setSystemDetails(
      engineDescription(
        getDetectorEngine()
      )
    );

    speak(
      "Анализ начат.",
      {
        priority: "normal",
        rate: 1,
        pitch: 1,
        volume: 1
      }
    );

    appState.analysisTimer =
      requestAnimationFrame(
        analysisLoop
      );
  } catch (
    error
  ) {
    console.error(
      "Ошибка запуска:",
      error
    );

    setStatus(
      "Ошибка",
      error.message ||
        "Не удалось запустить приложение."
    );

    setVoiceText(
      "Не удалось выполнить запуск."
    );

    setSystemDetails(
      "Проверьте модель SegFormer, соединение с интернетом и разрешение на камеру."
    );

    stopSpeaking();
  }
}

async function stopApp() {
  if (
    appState.analysisTimer
  ) {
    cancelAnimationFrame(
      appState.analysisTimer
    );

    appState.analysisTimer =
      null;
  }

  stopSpeaking();

  if (
    isCameraRunning(
      videoEl
    )
  ) {
    stopCamera(
      videoEl,
      () => {}
    );
  }

  await disposeDetector();

  clearOverlay();
  resetRuntimeState();

  isRunning =
    false;

  startBtn.textContent =
    "Запустить";

  setStatus(
    "Готово",
    "Анализ остановлен. Нажмите кнопку запуска."
  );

  setVoiceText(
    "Система остановлена."
  );

  setSystemDetails(
    engineDescription(
      getDetectorEngine()
    )
  );
}

async function switchDetectorEngine(
  nextEngine
) {
  const allowed = [
    "main-spatial",
    "segformer",
    "mediapipe"
  ];

  if (
    !allowed.includes(
      nextEngine
    )
  ) {
    setStatus(
      "Ошибка",
      "Неизвестный режим."
    );

    return;
  }

  const wasRunning =
    isRunning;

  if (
    wasRunning
  ) {
    await stopApp();
  }

  setDetectorEngine(
    nextEngine
  );

  resetRuntimeState();
  clearOverlay();
  updateDetectorInfo();

  setStatus(
    "Готово",
    `Выбран режим: ${engineTitle(nextEngine)}.`
  );

  setVoiceText(
    engineDescription(
      nextEngine
    )
  );

  setSystemDetails(
    engineDescription(
      nextEngine
    )
  );
}

async function installApp() {
  if (
    !deferredInstallPrompt
  ) {
    return;
  }

  deferredInstallPrompt.prompt();

  await deferredInstallPrompt.userChoice;

  deferredInstallPrompt =
    null;

  installBtn.classList.add(
    "hidden"
  );
}

async function registerServiceWorker() {
  if (
    !("serviceWorker" in navigator)
  ) {
    return;
  }

  try {
    await navigator.serviceWorker.register(
      "./sw.js"
    );

    console.log(
      "Service worker зарегистрирован."
    );
  } catch (
    error
  ) {
    console.error(
      "Ошибка регистрации service worker:",
      error
    );
  }
}

window.addEventListener(
  "beforeinstallprompt",
  (event) => {
    event.preventDefault();

    deferredInstallPrompt =
      event;

    installBtn.classList.remove(
      "hidden"
    );
  }
);

window.addEventListener(
  "appinstalled",
  () => {
    installBtn.classList.add(
      "hidden"
    );

    deferredInstallPrompt =
      null;
  }
);

window.addEventListener(
  "resize",
  syncOverlaySize
);

videoEl.addEventListener(
  "loadedmetadata",
  syncOverlaySize
);

startBtn.addEventListener(
  "click",
  async () => {
    if (
      isRunning
    ) {
      await stopApp();
    } else {
      await startApp();
    }
  }
);

installBtn.addEventListener(
  "click",
  installApp
);

setDetectorEngine(
  "main-spatial"
);

detectorModeEl.innerHTML = `
  <option value="main-spatial">
    SegFormer + MediaPipe
  </option>
  <option value="segformer">
    Только SegFormer
  </option>
  <option value="mediapipe">
    Только MediaPipe
  </option>
`;

detectorModeEl.value =
  "main-spatial";

detectorModeEl.addEventListener(
  "change",
  async (event) => {
    await switchDetectorEngine(
      event.target.value
    );
  }
);

updateDetectorInfo();

setStatus(
  "Готово",
  "Нажмите кнопку запуска, чтобы начать анализ."
);

setVoiceText(
  "Система готова к запуску."
);

setSystemDetails(
  engineDescription(
    getDetectorEngine()
  )
);

registerServiceWorker();

let lastCameraStatusCode =
  "";

let lastCameraWarningAt =
  0;

function checkCameraBeforeAnalysis(
  video,
  state
) {
  const status =
    getCameraStatus(video);

  state.cameraReady =
    status.ready;

  if (
    status.code !==
    lastCameraStatusCode
  ) {
    lastCameraStatusCode =
      status.code;

    console.log(
      "Состояние камеры:",
      status
    );
  }

  if (
    !status.ready
  ) {
    return false;
  }

  return true;
}
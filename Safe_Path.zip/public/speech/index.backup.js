﻿const CONFIG = {
  language: "ru-RU",
  rate: 0.95,
  pitch: 1.0,
  volume: 1.0,
  maxQueueSize: 3,
  browserStartTimeoutMs: 1200
};

const speechQueue = [];

let speaking = false;
let currentText = "";
let lastSpeechText = "";
let lastSpeechTime = 0;

let browserSpeechUnlocked = false;
let browserSpeechInitialized = false;
let availableVoices = [];
let selectedVoice = null;

function getCapacitor() {
  return window.Capacitor || null;
}

function getNativeTextToSpeech() {
  const capacitor = getCapacitor();

  if (!capacitor) {
    return null;
  }

  if (
    capacitor.Plugins &&
    capacitor.Plugins.TextToSpeech
  ) {
    return capacitor.Plugins.TextToSpeech;
  }

  if (
    capacitor.Plugins &&
    capacitor.Plugins.TextToSpeechPlugin
  ) {
    return capacitor.Plugins.TextToSpeechPlugin;
  }

  return null;
}

function isNativePlatform() {
  const capacitor = getCapacitor();

  if (!capacitor) {
    return false;
  }

  if (
    typeof capacitor.isNativePlatform ===
    "function"
  ) {
    return capacitor.isNativePlatform();
  }

  return (
    capacitor.getPlatform?.() === "android"
  );
}

function cleanText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

function getBrowserSpeech() {
  if (
    typeof window === "undefined" ||
    !("speechSynthesis" in window)
  ) {
    return null;
  }

  return window.speechSynthesis;
}

function updateVoices() {
  const synthesis = getBrowserSpeech();

  if (!synthesis) {
    availableVoices = [];
    selectedVoice = null;
    return [];
  }

  availableVoices = synthesis.getVoices() || [];

  selectedVoice =
    availableVoices.find((voice) =>
      String(voice.lang || "")
        .toLowerCase()
        .startsWith("ru-ru")
    ) ||
    availableVoices.find((voice) =>
      String(voice.lang || "")
        .toLowerCase()
        .startsWith("ru")
    ) ||
    null;

  return availableVoices;
}

function initializeBrowserSpeech() {
  const synthesis = getBrowserSpeech();

  if (!synthesis || browserSpeechInitialized) {
    return;
  }

  browserSpeechInitialized = true;

  updateVoices();

  synthesis.onvoiceschanged = () => {
    updateVoices();
  };
}

function getSpeechOptions(options = {}) {
  return {
    lang:
      options.language ||
      CONFIG.language,

    rate:
      Number(
        options.rate ??
        CONFIG.rate
      ),

    pitch:
      Number(
        options.pitch ??
        CONFIG.pitch
      ),

    volume:
      Number(
        options.volume ??
        CONFIG.volume
      ),

    queueStrategy:
      options.interrupt
        ? 0
        : 1
  };
}

function stopBrowserSpeech() {
  const synthesis = getBrowserSpeech();

  if (synthesis) {
    synthesis.cancel();
  }
}

function unlockBrowserSpeech() {
  const synthesis = getBrowserSpeech();

  if (!synthesis || browserSpeechUnlocked) {
    return;
  }

  try {
    const unlockUtterance =
      new SpeechSynthesisUtterance(" ");

    unlockUtterance.lang = CONFIG.language;
    unlockUtterance.volume = 0;
    unlockUtterance.rate = 1;

    synthesis.speak(unlockUtterance);
    browserSpeechUnlocked = true;
  } catch (error) {
    console.warn(
      "Не удалось разблокировать браузерную озвучку:",
      error
    );
  }
}

function waitForBrowserSpeechStart(synthesis) {
  return new Promise((resolve) => {
    const startedAt = Date.now();

    const timer = setInterval(() => {
      const isSpeaking = synthesis.speaking;
      const timeoutReached =
        Date.now() - startedAt >=
        CONFIG.browserStartTimeoutMs;

      if (isSpeaking || timeoutReached) {
        clearInterval(timer);
        resolve(isSpeaking);
      }
    }, 50);
  });
}

function speakBrowser(text, options = {}) {
  return new Promise((resolve) => {
    const synthesis = getBrowserSpeech();

    if (
      !synthesis ||
      !("SpeechSynthesisUtterance" in window)
    ) {
      resolve(false);
      return;
    }

    initializeBrowserSpeech();
    updateVoices();

    if (options.interrupt) {
      stopBrowserSpeech();
    }

    const utterance =
      new SpeechSynthesisUtterance(text);

    utterance.lang =
      options.language ||
      CONFIG.language;

    utterance.rate = Number(
      options.rate ??
      CONFIG.rate
    );

    utterance.pitch = Number(
      options.pitch ??
      CONFIG.pitch
    );

    utterance.volume = Number(
      options.volume ??
      CONFIG.volume
    );

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    let completed = false;

    const finish = () => {
      if (completed) {
        return;
      }

      completed = true;
      resolve(true);
    };

    utterance.onend = finish;
    utterance.onerror = finish;

    try {
      synthesis.speak(utterance);

      waitForBrowserSpeechStart(synthesis)
        .then((started) => {
          if (!started) {
            console.warn(
              "Браузерная озвучка не начала воспроизведение."
            );
          }
        })
        .catch(() => {});
    } catch (error) {
      console.error(
        "Ошибка браузерной озвучки:",
        error
      );

      finish();
    }
  });
}

async function speakAndroid(text, options = {}) {
  const plugin = getNativeTextToSpeech();

  if (
    !plugin ||
    typeof plugin.speak !== "function"
  ) {
    throw new Error(
      "Android TextToSpeech plugin недоступен."
    );
  }

  await plugin.speak({
    text,
    ...getSpeechOptions(options)
  });
}

async function speakOne(text, options = {}) {
  const native = isNativePlatform();

  if (native) {
    try {
      await speakAndroid(text, options);
      return true;
    } catch (error) {
      console.warn(
        "Нативная Android-озвучка недоступна. " +
        "Переход к browser speech:",
        error
      );
    }
  }

  return speakBrowser(text, options);
}

async function processQueue() {
  if (
    speaking ||
    speechQueue.length === 0
  ) {
    return;
  }

  speaking = true;

  const request = speechQueue.shift();

  currentText = request.text;

  try {
    await speakOne(
      request.text,
      request.options
    );
  } catch (error) {
    console.error(
      "Ошибка озвучки:",
      error
    );
  } finally {
    currentText = "";
    speaking = false;
  }

  if (speechQueue.length > 0) {
    await processQueue();
  }
}

export function initializeSpeech() {
  initializeBrowserSpeech();
  updateVoices();

  document.addEventListener(
    "click",
    unlockBrowserSpeech,
    { once: true }
  );

  document.addEventListener(
    "touchstart",
    unlockBrowserSpeech,
    { once: true, passive: true }
  );

  console.log(
    "Speech initialized. Native TTS:",
    isNativeSpeechAvailable()
  );
}

export function unlockSpeech() {
  unlockBrowserSpeech();
}

export async function speak(text, options = {}) {
  const value = cleanText(text);

  if (!value) {
    return;
  }

  const now = Date.now();

  const sameText =
    value === lastSpeechText;

  const cooldown = Number(
    options.cooldown ?? 0
  );

  if (
    sameText &&
    cooldown > 0 &&
    now - lastSpeechTime < cooldown
  ) {
    return;
  }

  lastSpeechText = value;
  lastSpeechTime = now;

  if (options.interrupt) {
    await stopSpeaking();
  }

  if (
    speechQueue.length >=
    CONFIG.maxQueueSize
  ) {
    speechQueue.shift();
  }

  speechQueue.push({
    text: value,
    options
  });

  await processQueue();
}

export async function speakHint(
  text,
  level = "info"
) {
  const isDanger =
    level === "danger";

  const isWarning =
    level === "warning";

  await speak(text, {
    interrupt: isDanger,

    rate: isDanger
      ? 1.05
      : isWarning
        ? 1.0
        : CONFIG.rate,

    cooldown: isDanger
      ? 1200
      : isWarning
        ? 3500
        : 5500
  });
}

export async function stopSpeaking() {
  speechQueue.length = 0;
  currentText = "";

  const plugin = getNativeTextToSpeech();

  if (
    plugin &&
    typeof plugin.stop === "function"
  ) {
    try {
      await plugin.stop();
    } catch (error) {
      console.warn(
        "Android TTS stop error:",
        error
      );
    }
  }

  stopBrowserSpeech();

  speaking = false;
}

export function isCurrentlySpeaking() {
  if (speaking) {
    return true;
  }

  const synthesis = getBrowserSpeech();

  if (synthesis) {
    return Boolean(synthesis.speaking);
  }

  return false;
}

export function getCurrentSpeechText() {
  return currentText;
}

export async function setSpeechLanguage(language) {
  const value = cleanText(language);

  if (!value) {
    return false;
  }

  CONFIG.language = value;

  updateVoices();

  const plugin = getNativeTextToSpeech();

  if (
    plugin &&
    typeof plugin.isLanguageSupported ===
    "function"
  ) {
    try {
      await plugin.isLanguageSupported({
        lang: value
      });
    } catch (error) {
      console.warn(
        "Язык TTS может быть недоступен:",
        value,
        error
      );
    }
  }

  return true;
}

export function setSpeechRate(rate) {
  const value = Number(rate);

  if (!Number.isFinite(value)) {
    return false;
  }

  CONFIG.rate = Math.max(
    0.1,
    Math.min(2.0, value)
  );

  return true;
}

export function setSpeechPitch(pitch) {
  const value = Number(pitch);

  if (!Number.isFinite(value)) {
    return false;
  }

  CONFIG.pitch = Math.max(
    0.1,
    Math.min(2.0, value)
  );

  return true;
}

export function getSpeechConfig() {
  return {
    ...CONFIG,
    nativeAvailable:
      isNativeSpeechAvailable(),
    browserUnlocked:
      browserSpeechUnlocked,
    voicesCount:
      availableVoices.length,
    selectedVoice:
      selectedVoice
        ? {
            name: selectedVoice.name,
            lang: selectedVoice.lang
          }
        : null
  };
}

export function isNativeSpeechAvailable() {
  return Boolean(
    getNativeTextToSpeech()
  );
}

export function resetSpeechState() {
  speechQueue.length = 0;

  speaking = false;
  currentText = "";
  lastSpeechText = "";
  lastSpeechTime = 0;

  stopBrowserSpeech();
}

initializeSpeech();

console.log(
  "Native TTS available:",
  isNativeSpeechAvailable()
);

console.log(
  "Capacitor platform:",
  window.Capacitor?.getPlatform?.()
);

console.log(
  "Capacitor plugins:",
  window.Capacitor?.Plugins
);
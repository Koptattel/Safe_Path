﻿const CONFIG = {
  language: "ru-RU",
  rate: 0.95,
  pitch: 1.0,
  volume: 1.0,
  cooldown: 1800,
  maxQueueSize: 3
};

let speaking = false;
let currentText = "";
let lastText = "";
let lastSpokenAt = 0;
let speechQueue = [];
let processingQueue = false;
let nativeSpeechAvailable = false;

function cleanText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

function hasAndroidTTS() {
  return Boolean(
    window.AndroidTTS &&
    typeof window.AndroidTTS.speak === "function"
  );
}

function hasBrowserTTS() {
  return Boolean(
    window.speechSynthesis &&
    window.SpeechSynthesisUtterance
  );
}

function isNativeSpeakingSupported() {
  return hasAndroidTTS();
}

function estimateSpeechDuration(text) {
  const words = cleanText(text)
    .split(" ")
    .filter(Boolean)
    .length;

  return Math.max(
    1200,
    Math.min(
      9000,
      words * 420
    )
  );
}

function removeDuplicateQueueItems(text) {
  speechQueue =
    speechQueue.filter(
      item => item.text !== text
    );
}

function addToQueue(
  text,
  options
) {
  removeDuplicateQueueItems(text);

  speechQueue.push({
    text,
    options,
    createdAt: Date.now()
  });

  if (
    speechQueue.length >
    CONFIG.maxQueueSize
  ) {
    speechQueue =
      speechQueue.slice(
        -CONFIG.maxQueueSize
      );
  }
}

function takeNextItem() {
  return speechQueue.shift() || null;
}

function speakNative(
  text,
  options
) {
  if (!hasAndroidTTS()) {
    return false;
  }

  if (
    options.interrupt &&
    typeof window.AndroidTTS.stop ===
      "function"
  ) {
    window.AndroidTTS.stop();
  }

  window.AndroidTTS.speak(text);

  return true;
}

function speakBrowser(
  text,
  options
) {
  if (!hasBrowserTTS()) {
    return false;
  }

  const utterance =
    new SpeechSynthesisUtterance(text);

  utterance.lang =
    options.language ||
    CONFIG.language;

  utterance.rate =
    options.rate ||
    CONFIG.rate;

  utterance.pitch =
    options.pitch ||
    CONFIG.pitch;

  utterance.volume =
    options.volume ||
    CONFIG.volume;

  utterance.onend = () => {
    finishCurrentSpeech();
  };

  utterance.onerror = () => {
    finishCurrentSpeech();
  };

  window.speechSynthesis.speak(
    utterance
  );

  return true;
}

function finishCurrentSpeech() {
  speaking = false;
  currentText = "";

  window.setTimeout(
    processQueue,
    80
  );
}

function fallbackFinish(
  expectedText
) {
  window.setTimeout(
    () => {
      if (
        speaking &&
        currentText === expectedText
      ) {
        finishCurrentSpeech();
      }
    },
    estimateSpeechDuration(
      expectedText
    )
  );
}

async function processQueue() {
  if (processingQueue) {
    return;
  }

  if (speaking) {
    return;
  }

  processingQueue = true;

  try {
    const item =
      takeNextItem();

    if (!item) {
      return;
    }

    const {
      text,
      options
    } = item;

    speaking = true;
    currentText = text;

    const started =
      isNativeSpeakingSupported()
        ? speakNative(
            text,
            options
          )
        : speakBrowser(
            text,
            options
          );

    if (!started) {
      finishCurrentSpeech();
      return;
    }

    if (
      isNativeSpeakingSupported()
    ) {
      fallbackFinish(text);
    }
  } finally {
    processingQueue = false;
  }
}

export async function speak(
  text,
  options = {}
) {
  const value =
    cleanText(text);

  if (!value) {
    return false;
  }

  const now =
    Date.now();

  const cooldown =
    Number(
      options.cooldown ||
      CONFIG.cooldown
    );

  const isDanger =
    options.level === "danger" ||
    options.interrupt === true;

  if (
    !isDanger &&
    value === lastText &&
    now - lastSpokenAt <
      cooldown
  ) {
    return false;
  }

  if (
    !isDanger &&
    speechQueue.some(
      item => item.text === value
    )
  ) {
    return false;
  }

  lastText = value;
  lastSpokenAt = now;

  if (
    isDanger
  ) {
    speechQueue =
      speechQueue.filter(
        item =>
          item.options?.level ===
          "danger"
      );

    addToQueue(
      value,
      {
        ...options,
        level: "danger",
        interrupt: false
      }
    );
  } else {
    addToQueue(
      value,
      {
        ...options,
        interrupt: false
      }
    );
  }

  await processQueue();

  return true;
}

export async function speakHint(
  text,
  level = "info"
) {
  return speak(
    text,
    {
      level,

      rate:
        level === "danger"
          ? 1.05
          : CONFIG.rate,

      cooldown:
        level === "danger"
          ? 1000
          : level === "warning"
            ? 3000
            : 5000
    }
  );
}

export async function stopSpeaking() {
  speechQueue = [];

  if (
    window.AndroidTTS &&
    typeof window.AndroidTTS.stop ===
      "function"
  ) {
    window.AndroidTTS.stop();
  }

  if (
    window.speechSynthesis
  ) {
    window.speechSynthesis.cancel();
  }

  speaking = false;
  currentText = "";
  processingQueue = false;
}

export function isCurrentlySpeaking() {
  return speaking;
}

export function getCurrentSpeechText() {
  return currentText;
}

export function getSpeechQueueLength() {
  return speechQueue.length;
}

export function isSpeechAvailable() {
  return Boolean(
    hasAndroidTTS() ||
    hasBrowserTTS()
  );
}

export function getSpeechConfig() {
  return {
    ...CONFIG
  };
}

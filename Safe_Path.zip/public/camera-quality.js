const CAMERA_CHECK_INTERVAL_MS = 5000;

const CAMERA_QUALITY_CONFIG = {
  minBrightness: 18,
  maxBrightness: 242,
  minContrast: 8,
  minFramePixels: 100,
  speakCooldownMs: 10000
};

let cameraCheckTimer = null;
let lastSpeakTime = 0;

function createHiddenCanvas() {
  const canvas = document.createElement("canvas");
  canvas.width = 64;
  canvas.height = 48;

  return {
    canvas,
    context: canvas.getContext("2d", {
      willReadFrequently: true
    })
  };
}

function analyzeCameraFrame(videoEl, canvas, context) {
  if (
    !videoEl ||
    !videoEl.videoWidth ||
    !videoEl.videoHeight
  ) {
    return {
      status: "unavailable",
      brightness: 0,
      contrast: 0
    };
  }

  context.drawImage(
    videoEl,
    0,
    0,
    canvas.width,
    canvas.height
  );

  const imageData = context.getImageData(
    0,
    0,
    canvas.width,
    canvas.height
  );

  const pixels = imageData.data;
  const totalPixels = canvas.width * canvas.height;

  let brightnessSum = 0;
  const brightnessValues = [];

  for (let index = 0; index < totalPixels; index += 1) {
    const red = pixels[index * 4];
    const green = pixels[index * 4 + 1];
    const blue = pixels[index * 4 + 2];

    const brightness =
      0.299 * red +
      0.587 * green +
      0.114 * blue;

    brightnessSum += brightness;
    brightnessValues.push(brightness);
  }

  const averageBrightness =
    brightnessSum / totalPixels;

  let varianceSum = 0;

  for (const brightness of brightnessValues) {
    const difference =
      brightness - averageBrightness;

    varianceSum += difference * difference;
  }

  const contrast =
    Math.sqrt(varianceSum / totalPixels);

  return {
    status: "ok",
    brightness: averageBrightness,
    contrast
  };
}

function isCameraBlocked(analysis) {
  if (analysis.status !== "ok") {
    return false;
  }

  const tooDark =
    analysis.brightness <
    CAMERA_QUALITY_CONFIG.minBrightness;

  const tooBright =
    analysis.brightness >
    CAMERA_QUALITY_CONFIG.maxBrightness;

  const tooUniform =
    analysis.contrast <
    CAMERA_QUALITY_CONFIG.minContrast;

  return tooDark || tooBright || tooUniform;
}

function speakCameraWarning() {
  const now = Date.now();

  if (
    now - lastSpeakTime <
    CAMERA_QUALITY_CONFIG.speakCooldownMs
  ) {
    return;
  }

  if (!("speechSynthesis" in window)) {
    return;
  }

  const message =
    "Проверьте камеру. Возможно, объектив закрыт или загрязнён.";

  const utterance = new SpeechSynthesisUtterance(message);
  utterance.lang = "ru-RU";
  utterance.rate = 1;
  utterance.volume = 1;

  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);

  lastSpeakTime = now;
}

export function startCameraQualityCheck(
  videoEl,
  onStatus = () => {}
) {
  stopCameraQualityCheck();

  const { canvas, context } = createHiddenCanvas();

  cameraCheckTimer = setInterval(() => {
    const analysis = analyzeCameraFrame(
      videoEl,
      canvas,
      context
    );

    if (isCameraBlocked(analysis)) {
      onStatus(
        "Камера закрыта, загрязнена или плохо освещена."
      );

      speakCameraWarning();
    }
  }, CAMERA_CHECK_INTERVAL_MS);

  onStatus("Проверка камеры запущена.");
}

export function stopCameraQualityCheck() {
  if (cameraCheckTimer) {
    clearInterval(cameraCheckTimer);
    cameraCheckTimer = null;
  }
}
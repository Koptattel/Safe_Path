﻿import {
  getWallHeuristicState
} from "./wall-heuristics.js";

const CONFIG = {
  zones: {
    forwardLeft: 0.20,
    forwardRight: 0.80,

    dangerLeft: 0.30,
    dangerRight: 0.70,

    nearBottom: 0.78
  },

  frames: {
    dangerRequired: 2,
    warningRequired: 2
  },

  speech: {
    dangerCooldown: 1800,
    warningCooldown: 4500,
    infoCooldown: 6500
  },

  objects: {
    person: {
      enabled: true,
      confidence: 0.65,
      priority: 100,
      level: "danger",
      speak: true,
      centerOnly: false,
      minArea: 0.006,
      name: "человек"
    },

    chair: {
      enabled: true,
      confidence: 0.45,
      priority: 85,
      level: "warning",
      speak: true,
      centerOnly: false,
      minArea: 0.008,
      name: "стул"
    },

    "dining table": {
      enabled: true,
      confidence: 0.35,
      priority: 95,
      level: "danger",
      speak: true,
      centerOnly: false,
      minArea: 0.010,
      name: "стол"
    },

    couch: {
      enabled: true,
      confidence: 0.35,
      priority: 80,
      level: "warning",
      speak: true,
      centerOnly: false,
      minArea: 0.012,
      name: "диван"
    },

    bed: {
      enabled: true,
      confidence: 0.40,
      priority: 70,
      level: "warning",
      speak: true,
      centerOnly: false,
      minArea: 0.018,
      name: "кровать"
    },

    bench: {
      enabled: true,
      confidence: 0.45,
      priority: 85,
      level: "warning",
      speak: true,
      centerOnly: false,
      minArea: 0.008,
      name: "скамейка"
    },

    suitcase: {
      enabled: true,
      confidence: 0.50,
      priority: 95,
      level: "danger",
      speak: true,
      centerOnly: false,
      minArea: 0.006,
      name: "чемодан"
    },

    backpack: {
      enabled: true,
      confidence: 0.55,
      priority: 75,
      level: "warning",
      speak: true,
      centerOnly: false,
      minArea: 0.006,
      name: "рюкзак"
    },

    handbag: {
      enabled: false,
      confidence: 0.65,
      priority: 30,
      level: "info",
      speak: false,
      centerOnly: false,
      minArea: 0.006,
      name: "сумка"
    },

    "potted plant": {
      enabled: true,
      confidence: 0.55,
      priority: 60,
      level: "warning",
      speak: true,
      centerOnly: false,
      minArea: 0.008,
      name: "растение"
    },

    door: {
      enabled: true,
      confidence: 0.40,
      priority: 90,
      level: "warning",
      speak: true,
      centerOnly: false,
      minArea: 0.006,
      name: "дверь"
    },

    stairs: {
      enabled: true,
      confidence: 0.35,
      priority: 100,
      level: "danger",
      speak: true,
      centerOnly: false,
      minArea: 0.006,
      name: "лестница"
    }
  }
};

let dangerFrames =
  0;

let warningFrames =
  0;

let lastSpeechKey =
  "";

let lastSpeechTime =
  0;

function clamp01(
  value
) {
  return Math.max(
    0,
    Math.min(
      1,
      Number(value) || 0
    )
  );
}

function normalizeLabel(
  label
) {
  const value =
    String(label || "")
      .trim()
      .toLowerCase();

  const aliases = {
    sofa: "couch",
    doorway: "door",
    "diningtable": "dining table",
    "pottedplant": "potted plant",
    "floor-obstacle": "obstacle",
    "large-obstacle": "obstacle"
  };

  return (
    aliases[value] ||
    value ||
    "unknown"
  );
}

function getSourceWeight(
  source
) {
  if (
    source === "segformer"
  ) {
    return 1.05;
  }

  if (
    source === "mediapipe"
  ) {
    return 1;
  }

  return 0.95;
}

function getLevelWeight(
  level
) {
  if (
    level === "danger"
  ) {
    return 3;
  }

  if (
    level === "warning"
  ) {
    return 2;
  }

  if (
    level === "info"
  ) {
    return 1;
  }

  return 0;
}

function getObjectSettings(
  label
) {
  return (
    CONFIG.objects[label] || {
      enabled: false,
      confidence: 1,
      priority: 0,
      level: "info",
      speak: false,
      centerOnly: true,
      minArea: 1,
      name: label
    }
  );
}

function getMetrics(
  item,
  frameWidth,
  frameHeight
) {
  const box =
    item?.box || {};

  const x =
    Number(box.x || 0);

  const y =
    Number(box.y || 0);

  const width =
    Math.max(
      0,
      Number(box.width || 0)
    );

  const height =
    Math.max(
      0,
      Number(box.height || 0)
    );

  const centerX =
    x + width / 2;

  const centerRatio =
    centerX /
    Math.max(
      1,
      frameWidth
    );

  const bottomRatio =
    (y + height) /
    Math.max(
      1,
      frameHeight
    );

  const areaRatio =
    width *
    height /
    Math.max(
      1,
      frameWidth *
        frameHeight
    );

  const inForwardZone =
    centerRatio >=
      CONFIG.zones.forwardLeft &&
    centerRatio <=
      CONFIG.zones.forwardRight;

  const inDangerZone =
    centerRatio >=
      CONFIG.zones.dangerLeft &&
    centerRatio <=
      CONFIG.zones.dangerRight;

  const nearBottom =
    bottomRatio >=
    CONFIG.zones.nearBottom;

  return {
    centerX,
    centerRatio,
    bottomRatio,
    areaRatio,
    inForwardZone,
    inDangerZone,
    nearBottom
  };
}

function getDirection(
  item
) {
  if (
    !item
  ) {
    return "впереди";
  }

  if (
    item.centerRatio <
    0.34
  ) {
    return "слева";
  }

  if (
    item.centerRatio >
    0.66
  ) {
    return "справа";
  }

  return "впереди";
}

function getDistance(
  item
) {
  if (
    !item
  ) {
    return "далеко";
  }

  if (
    item.areaRatio >=
      0.20 ||
    item.bottomRatio >=
      0.94
  ) {
    return "очень близко";
  }

  if (
    item.areaRatio >=
      0.08 ||
    item.bottomRatio >=
      0.82
  ) {
    return "близко";
  }

  if (
    item.areaRatio >=
      0.025 ||
    item.bottomRatio >=
      0.64
  ) {
    return "на среднем расстоянии";
  }

  return "далеко";
}

function getMessage(
  item
) {
  if (
    !item
  ) {
    return "Путь впереди свободен.";
  }

  const distance =
    getDistance(
      item
    );

  const direction =
    getDirection(
      item
    );

  const name =
    item.settings?.name ||
    item.label ||
    "объект";

  return (
    `${distance} ${name} ${direction}.`
  );
}

function enrichDetection(
  detection,
  frameWidth,
  frameHeight
) {
  const label =
    normalizeLabel(
      detection?.label
    );

  const settings =
    getObjectSettings(
      label
    );

  const score =
    clamp01(
      detection?.score
    );

  const metrics =
    getMetrics(
      detection,
      frameWidth,
      frameHeight
    );

  const accepted =
    settings.enabled &&
    score >=
      settings.confidence &&
    metrics.areaRatio >=
      settings.minArea &&
    (
      !settings.centerOnly ||
      metrics.inForwardZone
    );

  const sourceWeight =
    getSourceWeight(
      detection?.source
    );

  const risk =
    clamp01(
      score * 0.35 +
      Number(settings.priority) /
        100 *
        0.30 +
      clamp01(
        metrics.areaRatio * 8
      ) * 0.20 +
      (
        metrics.inDangerZone
          ? 0.10
          : 0
      ) +
      (
        metrics.nearBottom
          ? 0.05
          : 0
      )
    ) *
    sourceWeight;

  return {
    ...detection,

    label,

    score,

    settings,

    ...metrics,

    accepted,

    priority:
      Number(
        settings.priority
      ),

    level:
      settings.level,

    risk
  };
}

function boxesOverlap(
  first,
  second,
  frameWidth,
  frameHeight
) {
  const a =
    first.box || {};

  const b =
    second.box || {};

  const ax1 =
    Number(a.x || 0);

  const ay1 =
    Number(a.y || 0);

  const ax2 =
    ax1 +
    Number(a.width || 0);

  const ay2 =
    ay1 +
    Number(a.height || 0);

  const bx1 =
    Number(b.x || 0);

  const by1 =
    Number(b.y || 0);

  const bx2 =
    bx1 +
    Number(b.width || 0);

  const by2 =
    by1 +
    Number(b.height || 0);

  const intersectionWidth =
    Math.max(
      0,
      Math.min(
        ax2,
        bx2
      ) -
      Math.max(
        ax1,
        bx1
      )
    );

  const intersectionHeight =
    Math.max(
      0,
      Math.min(
        ay2,
        by2
      ) -
      Math.max(
        ay1,
        by1
      )
    );

  const intersectionArea =
    intersectionWidth *
    intersectionHeight;

  const firstArea =
    Math.max(
      1,
      Number(a.width || 0) *
      Number(a.height || 0)
    );

  const secondArea =
    Math.max(
      1,
      Number(b.width || 0) *
      Number(b.height || 0)
    );

  const smallerArea =
    Math.min(
      firstArea,
      secondArea
    );

  const centerDistance =
    Math.abs(
      first.centerRatio -
      second.centerRatio
    );

  const verticalDistance =
    Math.abs(
      first.bottomRatio -
      second.bottomRatio
    );

  const overlapRatio =
    intersectionArea /
    smallerArea;

  return (
    overlapRatio >= 0.35 ||
    (
      centerDistance <= 0.08 &&
      verticalDistance <= 0.12
    )
  );
}

function mergeDuplicateDetections(
  detections,
  frameWidth,
  frameHeight
) {
  const result =
    [];

  for (
    const detection of detections
  ) {
    let duplicate =
      null;

    for (
      const existing of result
    ) {
      if (
        existing.label !==
        detection.label
      ) {
        continue;
      }

      if (
        boxesOverlap(
          existing,
          detection,
          frameWidth,
          frameHeight
        )
      ) {
        duplicate =
          existing;

        break;
      }
    }

    if (
      !duplicate
    ) {
      result.push(
        detection
      );

      continue;
    }

    const preferred =
      compareObjects(
        detection,
        duplicate
      ) < 0
        ? detection
        : duplicate;

    const combinedScore =
      Math.max(
        duplicate.score,
        detection.score
      );

    duplicate =
      Object.assign(
        duplicate,
        preferred,
        {
          score:
            combinedScore,

          sources: [
            ...new Set([
              ...(duplicate.sources ||
                [duplicate.source]),
              ...(detection.sources ||
                [detection.source])
            ])
          ],

          risk:
            Math.max(
              duplicate.risk,
              detection.risk
            )
        }
      );

    const index =
      result.indexOf(
        result.find(
          (item) =>
            item ===
            result.find(
              (candidate) =>
                candidate.label ===
                  detection.label &&
                candidate !==
                  detection
            )
        )
      );

    if (
      index >= 0
    ) {
      result[index] =
        duplicate;
    }
  }

  return result;
}

function compareObjects(
  first,
  second
) {
  const firstLevel =
    getLevelWeight(
      first.level
    );

  const secondLevel =
    getLevelWeight(
      second.level
    );

  if (
    firstLevel !==
    secondLevel
  ) {
    return secondLevel -
      firstLevel;
  }

  if (
    first.priority !==
    second.priority
  ) {
    return second.priority -
      first.priority;
  }

  if (
    first.inDangerZone !==
    second.inDangerZone
  ) {
    return (
      Number(second.inDangerZone) -
      Number(first.inDangerZone)
    );
  }

  if (
    first.nearBottom !==
    second.nearBottom
  ) {
    return (
      Number(second.nearBottom) -
      Number(first.nearBottom)
    );
  }

  if (
    first.risk !==
    second.risk
  ) {
    return second.risk -
      first.risk;
  }

  return second.score -
    first.score;
}

function selectImportantObjects(
  detections,
  frameWidth,
  frameHeight
) {
  if (
    !Array.isArray(detections)
  ) {
    return [];
  }

  const enriched =
    detections
      .map(
        (item) =>
          enrichDetection(
            item,
            frameWidth,
            frameHeight
          )
      )
      .filter(
        (item) =>
          item.accepted
      );

  return mergeDuplicateDetections(
    enriched,
    frameWidth,
    frameHeight
  )
    .sort(
      compareObjects
    )
    .slice(
      0,
      8
    );
}

function chooseMainObject(
  objects
) {
  if (
    !objects.length
  ) {
    return null;
  }

  const forwardObjects =
    objects.filter(
      (item) =>
        item.inForwardZone
    );

  return (
    forwardObjects.sort(
      compareObjects
    )[0] ||
    objects[0]
  );
}

function chooseSpeechObject(
  objects
) {
  return (
    objects
      .filter(
        (item) =>
          item.settings.speak
      )
      .filter(
        (item) =>
          item.inForwardZone
      )
      .sort(
        compareObjects
      )[0] ||
    null
  );
}

function canSpeak(
  item,
  level
) {
  if (
    !item ||
    !item.settings.speak
  ) {
    return false;
  }

  const key =
    `${item.label}:${getDirection(item)}:${getDistance(item)}`;

  const now =
    Date.now();

  let cooldown =
    CONFIG.speech.infoCooldown;

  if (
    level === "danger"
  ) {
    cooldown =
      CONFIG.speech.dangerCooldown;
  }

  if (
    level === "warning"
  ) {
    cooldown =
      CONFIG.speech.warningCooldown;
  }

  const changed =
    key !==
    lastSpeechKey;

  const timePassed =
    now -
      lastSpeechTime >=
    cooldown;

  if (
    !changed &&
    !timePassed
  ) {
    return false;
  }

  lastSpeechKey =
    key;

  lastSpeechTime =
    now;

  return true;
}

function mergeWallState(
  objectState,
  wallState
) {
  if (
    !wallState ||
    !wallState.text
  ) {
    return objectState;
  }

  if (
    getLevelWeight(
      wallState.level
    ) >
    getLevelWeight(
      objectState.level
    )
  ) {
    return {
      ...wallState,

      debug: {
        ...objectState.debug,
        ...wallState.debug,
        wallState
      }
    };
  }

  return {
    ...objectState,

    debug: {
      ...objectState.debug,
      wallState
    }
  };
}

export function getHintStateFromDetections(
  detections = [],
  frameWidth = 640,
  frameHeight = 480
) {
  const important =
    selectImportantObjects(
      detections,
      frameWidth,
      frameHeight
    );

  const mainObject =
    chooseMainObject(
      important
    );

  const speechObject =
    chooseSpeechObject(
      important
    );

  const wallState =
    getWallHeuristicState(
      detections,
      frameWidth,
      frameHeight
    );

  if (
    !mainObject
  ) {
    dangerFrames =
      0;

    warningFrames =
      0;

    return {
      level:
        wallState?.level ===
        "warning"
          ? "warning"
          : "safe",

      text:
        wallState?.text ||
        "Путь впереди свободен.",

      shouldSpeak:
        Boolean(
          wallState?.shouldSpeak
        ),

      forceInterrupt:
        false,

      debug: {
        total:
          Array.isArray(detections)
            ? detections.length
            : 0,

        filtered:
          important.length,

        important,

        mainObstacle:
          null,

        spokenObject:
          null,

        wallState,

        direction:
          "впереди",

        distance:
          "далеко",

        dangerFrames,

        warningFrames
      }
    };
  }

  if (
    mainObject.level ===
    "danger"
  ) {
    dangerFrames +=
      1;

    warningFrames =
      0;
  } else if (
    mainObject.level ===
    "warning"
  ) {
    warningFrames +=
      1;

    dangerFrames =
      0;
  } else {
    dangerFrames =
      0;

    warningFrames =
      0;
  }

  const dangerConfirmed =
    mainObject.level ===
      "danger" &&
    dangerFrames >=
      CONFIG.frames
        .dangerRequired;

  const warningConfirmed =
    mainObject.level ===
      "warning" &&
    warningFrames >=
      CONFIG.frames
        .warningRequired;

  let level =
    mainObject.level;

  if (
    dangerConfirmed
  ) {
    level =
      "danger";
  } else if (
    warningConfirmed
  ) {
    level =
      "warning";
  }

  const selected =
    speechObject ||
    mainObject;

  const text =
    getMessage(
      selected
    );

  const shouldSpeak =
    (
      dangerConfirmed ||
      warningConfirmed
    ) &&
    canSpeak(
      selected,
      level
    );

  const objectState = {
    level,

    text,

    shouldSpeak,

    forceInterrupt:
      dangerConfirmed,

    debug: {
      total:
        Array.isArray(detections)
          ? detections.length
          : 0,

      filtered:
        important.length,

      important,

      mainObstacle:
        mainObject,

      spokenObject:
        speechObject,

      wallState,

      direction:
        getDirection(
          selected
        ),

      distance:
        getDistance(
          selected
        ),

      selectedConfidence:
        selected.score,

      selectedPriority:
        selected.priority,

      selectedRisk:
        selected.risk,

      sources:
        selected.sources ||
        [selected.source],

      dangerFrames,

      warningFrames
    }
  };

  return mergeWallState(
    objectState,
    wallState
  );
}

export function resetLogic() {
  dangerFrames =
    0;

  warningFrames =
    0;

  lastSpeechKey =
    "";

  lastSpeechTime =
    0;
}

export function getLogicConfig() {
  return CONFIG;
}

export function setObjectConfidence(
  label,
  confidence
) {
  const normalized =
    normalizeLabel(
      label
    );

  if (
    !CONFIG.objects[
      normalized
    ]
  ) {
    return false;
  }

  CONFIG.objects[
    normalized
  ].confidence =
    clamp01(
      confidence
    );

  return true;
}

export function setObjectPriority(
  label,
  priority
) {
  const normalized =
    normalizeLabel(
      label
    );

  if (
    !CONFIG.objects[
      normalized
    ]
  ) {
    return false;
  }

  CONFIG.objects[
    normalized
  ].priority =
    Math.max(
      0,
      Math.min(
        100,
        Number(priority) || 0
      )
    );

  return true;
}

export function setObjectEnabled(
  label,
  enabled
) {
  const normalized =
    normalizeLabel(
      label
    );

  if (
    !CONFIG.objects[
      normalized
    ]
  ) {
    return false;
  }

  CONFIG.objects[
    normalized
  ].enabled =
    Boolean(
      enabled
    );

  return true;
}

export function setObjectSpeech(
  label,
  enabled
) {
  const normalized =
    normalizeLabel(
      label
    );

  if (
    !CONFIG.objects[
      normalized
    ]
  ) {
    return false;
  }

  CONFIG.objects[
    normalized
  ].speak =
    Boolean(
      enabled
    );

  return true;
}
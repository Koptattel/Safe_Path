﻿const WALL_CONFIG = {
  wallMinimumConfidence: 0.75,

  objectMinimumConfidence: 0.52,

  wallMinimumAreaRatio: 0.055,

  objectMinimumAreaRatio: 0.006,

  objectMinimumBottomRatio: 0.42,

  objectMinimumWidthRatio: 0.018,

  wallMinimumWidthRatio: 0.18,

  wallMinimumHeightRatio: 0.25,

  sideNearOccupancy: 0.30,

  sideStrongOccupancy: 0.48,

  centerClearMaximum: 0.08,

  leftBoundary: 0.30,

  rightBoundary: 0.70,

  nearBottomRatio: 0.82,

  veryNearBottomRatio: 0.94,

  veryNearAreaRatio: 0.18,

  nearAreaRatio: 0.065,

  mediumAreaRatio: 0.018,

  speakStrongWarning: true
};

const OBJECT_SETTINGS = {
  person: {
    name: "человек",
    priority: 100,
    minimumConfidence: 0.58,
    minimumAreaRatio: 0.008,
    minimumBottomRatio: 0.42,
    level: "danger"
  },

  stairs: {
    name: "лестница",
    priority: 100,
    minimumConfidence: 0.62,
    minimumAreaRatio: 0.012,
    minimumBottomRatio: 0.38,
    level: "danger"
  },

  door: {
    name: "дверь",
    priority: 80,
    minimumConfidence: 0.60,
    minimumAreaRatio: 0.012,
    minimumBottomRatio: 0.45,
    level: "warning"
  },

  chair: {
    name: "стул",
    priority: 75,
    minimumConfidence: 0.58,
    minimumAreaRatio: 0.009,
    minimumBottomRatio: 0.55,
    level: "warning"
  },

  "dining table": {
    name: "стол",
    priority: 90,
    minimumConfidence: 0.58,
    minimumAreaRatio: 0.012,
    minimumBottomRatio: 0.52,
    level: "danger"
  },

  couch: {
    name: "диван",
    priority: 70,
    minimumConfidence: 0.58,
    minimumAreaRatio: 0.018,
    minimumBottomRatio: 0.52,
    level: "warning"
  },

  bed: {
    name: "кровать",
    priority: 65,
    minimumConfidence: 0.60,
    minimumAreaRatio: 0.025,
    minimumBottomRatio: 0.50,
    level: "warning"
  },

  bench: {
    name: "скамейка",
    priority: 75,
    minimumConfidence: 0.58,
    minimumAreaRatio: 0.010,
    minimumBottomRatio: 0.55,
    level: "warning"
  },

  suitcase: {
    name: "чемодан",
    priority: 90,
    minimumConfidence: 0.60,
    minimumAreaRatio: 0.008,
    minimumBottomRatio: 0.62,
    level: "danger"
  },

  backpack: {
    name: "рюкзак",
    priority: 65,
    minimumConfidence: 0.62,
    minimumAreaRatio: 0.008,
    minimumBottomRatio: 0.60,
    level: "warning"
  },

  handbag: {
    name: "сумка",
    priority: 45,
    minimumConfidence: 0.68,
    minimumAreaRatio: 0.010,
    minimumBottomRatio: 0.64,
    level: "warning"
  },

  "potted plant": {
    name: "растение",
    priority: 60,
    minimumConfidence: 0.62,
    minimumAreaRatio: 0.010,
    minimumBottomRatio: 0.52,
    level: "warning"
  },

  obstacle: {
    name: "препятствие",
    priority: 95,
    minimumConfidence: 0.72,
    minimumAreaRatio: 0.012,
    minimumBottomRatio: 0.55,
    level: "danger"
  },

  wall: {
    name: "стена",
    priority: 85,
    minimumConfidence: 0.90,
    minimumAreaRatio: 0.055,
    minimumBottomRatio: 0.25,
    level: "warning"
  }
};

const LABEL_ALIASES = {
  sofa: "couch",
  doorway: "door",
  "diningtable": "dining table",
  "pottedplant": "potted plant",
  "floor-obstacle": "obstacle",
  "large-obstacle": "obstacle"
};

function clamp01(
  value
) {
  return Math.max(
    0,
    Math.min(
      1,
      Number(value) || 0
    )
  );
}

function normalizeLabel(
  label
) {
  const value =
    String(label || "")
      .trim()
      .toLowerCase();

  return (
    LABEL_ALIASES[value] ||
    value ||
    "unknown"
  );
}

function getAreaRatio(
  box,
  frameWidth,
  frameHeight
) {
  const width =
    Math.max(
      0,
      Number(box?.width || 0)
    );

  const height =
    Math.max(
      0,
      Number(box?.height || 0)
    );

  return (
    width *
    height /
    Math.max(
      1,
      frameWidth *
      frameHeight
    )
  );
}

function getBoxMetrics(
  box,
  frameWidth,
  frameHeight
) {
  const frameW =
    Math.max(
      1,
      Number(frameWidth) || 1
    );

  const frameH =
    Math.max(
      1,
      Number(frameHeight) || 1
    );

  const x =
    Number(box?.x || 0);

  const y =
    Number(box?.y || 0);

  const width =
    Math.max(
      0,
      Number(box?.width || 0)
    );

  const height =
    Math.max(
      0,
      Number(box?.height || 0)
    );

  const centerX =
    x +
    width /
    2;

  const bottomY =
    y +
    height;

  const centerRatio =
    clamp01(
      centerX /
      frameW
    );

  const bottomRatio =
    clamp01(
      bottomY /
      frameH
    );

  const widthRatio =
    clamp01(
      width /
      frameW
    );

  const heightRatio =
    clamp01(
      height /
      frameH
    );

  const areaRatio =
    getAreaRatio(
      box,
      frameW,
      frameH
    );

  return {
    x,
    y,
    width,
    height,
    centerX,
    bottomY,
    centerRatio,
    bottomRatio,
    widthRatio,
    heightRatio,
    areaRatio
  };
}

function getZone(
  centerRatio
) {
  if (
    centerRatio <
    WALL_CONFIG.leftBoundary
  ) {
    return "left";
  }

  if (
    centerRatio >
    WALL_CONFIG.rightBoundary
  ) {
    return "right";
  }

  return "center";
}

function getDirectionText(
  zone
) {
  if (
    zone === "left"
  ) {
    return "слева";
  }

  if (
    zone === "right"
  ) {
    return "справа";
  }

  return "впереди";
}

function getDistance(
  metrics
) {
  if (
    metrics.bottomRatio >=
      WALL_CONFIG.veryNearBottomRatio ||
    metrics.areaRatio >=
      WALL_CONFIG.veryNearAreaRatio
  ) {
    return "очень близко";
  }

  if (
    metrics.bottomRatio >=
      WALL_CONFIG.nearBottomRatio ||
    metrics.areaRatio >=
      WALL_CONFIG.nearAreaRatio
  ) {
    return "близко";
  }

  if (
    metrics.areaRatio >=
    WALL_CONFIG.mediumAreaRatio
  ) {
    return "на среднем расстоянии";
  }

  return "далеко";
}

function getDistanceRank(
  metrics
) {
  if (
    metrics.bottomRatio >=
      WALL_CONFIG.veryNearBottomRatio ||
    metrics.areaRatio >=
      WALL_CONFIG.veryNearAreaRatio
  ) {
    return 3;
  }

  if (
    metrics.bottomRatio >=
      WALL_CONFIG.nearBottomRatio ||
    metrics.areaRatio >=
      WALL_CONFIG.nearAreaRatio
  ) {
    return 2;
  }

  if (
    metrics.areaRatio >=
    WALL_CONFIG.mediumAreaRatio
  ) {
    return 1;
  }

  return 0;
}

function getObjectSettings(
  label
) {
  return (
    OBJECT_SETTINGS[label] ||
    null
  );
}

function getRequiredConfidence(
  label,
  settings
) {
  if (
    label === "wall"
  ) {
    return WALL_CONFIG.wallMinimumConfidence;
  }

  return Math.max(
    WALL_CONFIG.objectMinimumConfidence,
    settings?.minimumConfidence ||
      0
  );
}

function getRequiredArea(
  label,
  settings
) {
  if (
    label === "wall"
  ) {
    return WALL_CONFIG.wallMinimumAreaRatio;
  }

  return Math.max(
    WALL_CONFIG.objectMinimumAreaRatio,
    settings?.minimumAreaRatio ||
      0
  );
}

function isUsableDetection(
  item,
  frameWidth,
  frameHeight
) {
  if (
    !item ||
    !item.box
  ) {
    return null;
  }

  const label =
    normalizeLabel(
      item.label
    );

  const settings =
    getObjectSettings(
      label
    );

  if (
    !settings
  ) {
    return null;
  }

  const score =
    clamp01(
      item.score
    );

  const metrics =
    getBoxMetrics(
      item.box,
      frameWidth,
      frameHeight
    );

  const requiredConfidence =
    getRequiredConfidence(
      label,
      settings
    );

  const requiredArea =
    getRequiredArea(
      label,
      settings
    );

  if (
    score <
    requiredConfidence
  ) {
    return null;
  }

  if (
    metrics.areaRatio <
    requiredArea
  ) {
    return null;
  }

  if (
    metrics.widthRatio <
    WALL_CONFIG.objectMinimumWidthRatio
  ) {
    return null;
  }

  if (
    metrics.bottomRatio <
    (
      settings.minimumBottomRatio ||
      WALL_CONFIG.objectMinimumBottomRatio
    )
  ) {
    return null;
  }

  if (
    label === "wall" &&
    (
      metrics.widthRatio <
      WALL_CONFIG.wallMinimumWidthRatio ||
      metrics.heightRatio <
      WALL_CONFIG.wallMinimumHeightRatio
    )
  ) {
    return null;
  }

  const zone =
    getZone(
      metrics.centerRatio
    );

  const distance =
    getDistance(
      metrics
    );

  const distanceRank =
    getDistanceRank(
      metrics
    );

  const direction =
    getDirectionText(
      zone
    );

  const dangerPositionBonus =
    zone === "center"
      ? 0.20
      : 0;

  const closenessBonus =
    distanceRank *
    0.12;

  const risk =
    clamp01(
      score *
        0.48 +
      Math.min(
        1,
        metrics.areaRatio *
        5
      ) *
        0.22 +
      dangerPositionBonus +
      closenessBonus
    );

  return {
    ...item,

    label,

    rawLabel:
      item.label,

    score,

    source:
      item.source ||
      "unknown",

    box: {
      ...item.box
    },

    areaRatio:
      metrics.areaRatio,

    centerRatio:
      metrics.centerRatio,

    bottomRatio:
      metrics.bottomRatio,

    widthRatio:
      metrics.widthRatio,

    heightRatio:
      metrics.heightRatio,

    zone,

    direction,

    distance,

    distanceRank,

    risk,

    priority:
      settings.priority,

    level:
      settings.level,

    name:
      settings.name,

    isWall:
      label === "wall"
  };
}

function compareObjects(
  first,
  second
) {
  if (
    first.level !==
    second.level
  ) {
    const levelWeight = {
      danger: 3,
      warning: 2,
      info: 1
    };

    return (
      levelWeight[second.level] -
      levelWeight[first.level]
    );
  }

  if (
    first.distanceRank !==
    second.distanceRank
  ) {
    return (
      second.distanceRank -
      first.distanceRank
    );
  }

  if (
    first.priority !==
    second.priority
  ) {
    return (
      second.priority -
      first.priority
    );
  }

  return (
    second.risk -
    first.risk
  );
}

function getOverlap(
  startA,
  endA,
  startB,
  endB
) {
  return Math.max(
    0,
    Math.min(
      endA,
      endB
    ) -
    Math.max(
      startA,
      startB
    )
  );
}

function getZoneContribution(
  box,
  frameWidth,
  frameHeight
) {
  const metrics =
    getBoxMetrics(
      box,
      frameWidth,
      frameHeight
    );

  const x1 =
    clamp01(
      metrics.x /
      Math.max(
        1,
        frameWidth
      )
    );

  const x2 =
    clamp01(
      (
        metrics.x +
        metrics.width
      ) /
      Math.max(
        1,
        frameWidth
      )
    );

  const totalWidth =
    Math.max(
      0.0001,
      x2 -
      x1
    );

  const leftOverlap =
    getOverlap(
      x1,
      x2,
      0,
      WALL_CONFIG.leftBoundary
    );

  const centerOverlap =
    getOverlap(
      x1,
      x2,
      WALL_CONFIG.leftBoundary,
      WALL_CONFIG.rightBoundary
    );

  const rightOverlap =
    getOverlap(
      x1,
      x2,
      WALL_CONFIG.rightBoundary,
      1
    );

  return {
    left:
      metrics.areaRatio *
      leftOverlap /
      totalWidth,

    center:
      metrics.areaRatio *
      centerOverlap /
      totalWidth,

    right:
      metrics.areaRatio *
      rightOverlap /
      totalWidth
  };
}

function collectObjects(
  detections,
  frameWidth,
  frameHeight
) {
  if (
    !Array.isArray(detections)
  ) {
    return [];
  }

  return detections
    .map(
      (item) =>
        isUsableDetection(
          item,
          frameWidth,
          frameHeight
        )
    )
    .filter(
      Boolean
    )
    .sort(
      compareObjects
    );
}

function removeDuplicateObjects(
  objects
) {
  const result =
    [];

  for (
    const object of objects
  ) {
    const duplicate =
      result.find(
        (existing) =>
          existing.label ===
            object.label &&
          Math.abs(
            existing.centerRatio -
            object.centerRatio
          ) <
            0.08 &&
          Math.abs(
            existing.bottomRatio -
            object.bottomRatio
          ) <
            0.12
      );

    if (
      !duplicate
    ) {
      result.push(
        object
      );

      continue;
    }

    if (
      compareObjects(
        object,
        duplicate
      ) < 0
    ) {
      const index =
        result.indexOf(
          duplicate
        );

      result[index] =
        object;
    }
  }

  return result;
}

function collectWallEvidence(
  walls,
  frameWidth,
  frameHeight
) {
  const evidence = {
    left: 0,
    center: 0,
    right: 0,

    leftItems: [],
    centerItems: [],
    rightItems: []
  };

  for (
    const wall of walls
  ) {
    const contribution =
      getZoneContribution(
        wall.box,
        frameWidth,
        frameHeight
      );

    evidence.left +=
      contribution.left *
      wall.score;

    evidence.center +=
      contribution.center *
      wall.score;

    evidence.right +=
      contribution.right *
      wall.score;

    if (
      contribution.left >
      0
    ) {
      evidence.leftItems.push(
        wall
      );
    }

    if (
      contribution.center >
      0
    ) {
      evidence.centerItems.push(
        wall
      );
    }

    if (
      contribution.right >
      0
    ) {
      evidence.rightItems.push(
        wall
      );
    }
  }

  evidence.left =
    clamp01(
      evidence.left
    );

  evidence.center =
    clamp01(
      evidence.center
    );

  evidence.right =
    clamp01(
      evidence.right
    );

  return evidence;
}

function chooseMainObject(
  objects
) {
  if (
    !objects.length
  ) {
    return null;
  }

  return objects
    .slice()
    .sort(
      compareObjects
    )[0];
}

function getObjectText(
  object
) {
  if (
    !object
  ) {
    return "";
  }

  return (
    `${object.distance} ` +
    `${object.name} ` +
    `${object.direction}.`
  );
}

export function getWallHeuristicState(
  detections = [],
  frameWidth = 640,
  frameHeight = 480
) {
  const allObjects =
    collectObjects(
      detections,
      frameWidth,
      frameHeight
    );

  const objects =
    removeDuplicateObjects(
      allObjects
    );

  const walls =
    objects.filter(
      (item) =>
        item.isWall
    );

  const otherObjects =
    objects.filter(
      (item) =>
        !item.isWall
    );

  const evidence =
    collectWallEvidence(
      walls,
      frameWidth,
      frameHeight
    );

  const leftWallLikely =
    evidence.left >=
      WALL_CONFIG.sideNearOccupancy &&
    evidence.center <=
      WALL_CONFIG.centerClearMaximum;

  const rightWallLikely =
    evidence.right >=
      WALL_CONFIG.sideNearOccupancy &&
    evidence.center <=
      WALL_CONFIG.centerClearMaximum;

  const leftWallStrong =
    evidence.left >=
      WALL_CONFIG.sideStrongOccupancy &&
    evidence.center <=
      WALL_CONFIG.centerClearMaximum;

  const rightWallStrong =
    evidence.right >=
      WALL_CONFIG.sideStrongOccupancy &&
    evidence.center <=
      WALL_CONFIG.centerClearMaximum;

  const mainObject =
    chooseMainObject(
      otherObjects
    );

  const baseState = {
    leftWallLikely,

    rightWallLikely,

    leftWallStrong,

    rightWallStrong,

    text: "",

    level: "info",

    shouldSpeak: false,

    objects,

    walls,

    otherObjects,

    mainObject,

    debug: {
      acceptedObjects:
        objects,

      acceptedWalls:
        walls,

      acceptedOtherObjects:
        otherObjects,

      occupancy: {
        left:
          evidence.left,

        center:
          evidence.center,

        right:
          evidence.right
      }
    }
  };

  if (
    leftWallStrong &&
    rightWallStrong
  ) {
    return {
      ...baseState,

      level: "warning",

      text:
        "Узкий проход. " +
        "Слева и справа близкие стены.",

      shouldSpeak:
        WALL_CONFIG.speakStrongWarning
    };
  }

  if (
    leftWallStrong
  ) {
    return {
      ...baseState,

      level: "warning",

      text:
        "Слева близкая стена. " +
        "Держитесь правее.",

      shouldSpeak:
        WALL_CONFIG.speakStrongWarning
    };
  }

  if (
    rightWallStrong
  ) {
    return {
      ...baseState,

      level: "warning",

      text:
        "Справа близкая стена. " +
        "Держитесь левее.",

      shouldSpeak:
        WALL_CONFIG.speakStrongWarning
    };
  }

  if (
    mainObject
  ) {
    return {
      ...baseState,

      level:
        mainObject.level,

      text:
        getObjectText(
          mainObject
        ),

      shouldSpeak:
        mainObject.level ===
        "danger"
    };
  }

  if (
    leftWallLikely &&
    rightWallLikely
  ) {
    return {
      ...baseState,

      text:
        "По бокам стены.",

      shouldSpeak: false
    };
  }

  if (
    leftWallLikely
  ) {
    return {
      ...baseState,

      text:
        "Слева стена.",

      shouldSpeak: false
    };
  }

  if (
    rightWallLikely
  ) {
    return {
      ...baseState,

      text:
        "Справа стена.",

      shouldSpeak: false
    };
  }

  return baseState;
}

export function getWallHeuristicsConfig() {
  return {
    ...WALL_CONFIG,

    objectSettings: {
      ...OBJECT_SETTINGS
    }
  };
}

export function setWallHeuristicsConfig(
  patch = {}
) {
  Object.assign(
    WALL_CONFIG,
    patch
  );
}

export function getAcceptedObjects(
  detections = [],
  frameWidth = 640,
  frameHeight = 480
) {
  return removeDuplicateObjects(
    collectObjects(
      detections,
      frameWidth,
      frameHeight
    )
  );
}

export function getMainDetectedObject(
  detections = [],
  frameWidth = 640,
  frameHeight = 480
) {
  const objects =
    getAcceptedObjects(
      detections,
      frameWidth,
      frameHeight
    );

  return chooseMainObject(
    objects.filter(
      (item) =>
        !item.isWall
    )
  );
}
﻿const CACHE_NAME =
  "safe-path-v7";

const APP_SHELL = [
  "./",
  "./index.html",
  "./styles.css",
  "./main.js",
  "./manifest.json",
  "./camera/index.js",
  "./speech/index.js",
  "./state/index.js",
  "./logic/index.js",
  "./detection/index.js",
  "./detection/utils/detection-normalize.js",
  "./detection/detectors/detector-manager.js",
  "./detection/detectors/mediapipe-detector.js",
  "./detection/detectors/custom-detector.js",
  "./detection/detectors/segformer-detector.js"
];

self.addEventListener(
  "install",
  (event) => {
    self.skipWaiting();

    event.waitUntil(
      caches.open(CACHE_NAME)
        .then(async (cache) => {
          for (
            const file of APP_SHELL
          ) {
            try {
              await cache.add(file);
            } catch (error) {
              console.warn(
                "Cache skipped:",
                file
              );
            }
          }
        })
    );
  }
);

self.addEventListener(
  "activate",
  (event) => {
    event.waitUntil(
      caches.keys()
        .then((keys) =>
          Promise.all(
            keys
              .filter(
                (key) =>
                  key !== CACHE_NAME
              )
              .map((key) =>
                caches.delete(key)
              )
          )
        )
    );

    self.clients.claim();
  }
);

self.addEventListener(
  "fetch",
  (event) => {
    if (
      event.request.method !== "GET"
    ) {
      return;
    }

    const url =
      new URL(event.request.url);

    if (
      url.origin !==
      self.location.origin
    ) {
      return;
    }

    event.respondWith(
      caches.match(event.request)
        .then((cached) => {
          if (cached) {
            return cached;
          }

          return fetch(event.request);
        })
        .catch(() =>
          fetch(event.request)
        )
    );
  }
);